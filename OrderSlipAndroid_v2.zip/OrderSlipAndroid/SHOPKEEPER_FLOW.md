# Shopkeeper flow

When a user logs in with the Firestore role `storekeeper`, the app opens a live Shopkeeper dashboard instead of the New Order form.

The dashboard separates pending orders into:
- H.B MALL
- H.B KHARTHIYATH
- H.B SOUQ

Selecting an order opens a checklist. The storekeeper can tick items/sizes and mark the order complete. Completing an order changes its Firestore status to `completed`, so it disappears from the pending dashboard.

Shop orders are submitted directly to Firestore collection `orders`; WhatsApp is not required for the in-app workflow.
