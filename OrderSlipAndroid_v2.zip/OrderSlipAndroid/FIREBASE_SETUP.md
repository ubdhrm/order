# Firebase setup for Order Slip

Project: `hb-order-slip`
Android package: `com.orderslip.app`

## 1. Authentication

Firebase Console → Build → Authentication → Sign-in method:

- Enable **Email/Password** for Admin and Storekeeper.
- Enable **Anonymous** for Shop entry.

The app uses the Firebase Web SDK inside the existing WebView, so the existing Order Slip UI/features remain intact.

## 2. Admin user

Create the Admin user under Authentication → Users. Example used during setup:

- Email: `ubd343@hb.com`
- Password: the password you set in Firebase

Then Firestore → `users` → document ID must be the Admin Firebase **UID**, with:

- `role`: `admin`
- `name`: `Admin` (optional)

## 3. Storekeeper user

Create another Email/Password user, then create `users/{UID}` with:

- `role`: `storekeeper`
- `name`: `Storekeeper` (optional)

## 4. Firestore rules

Use the rules in `FIREBASE_FIRESTORE_RULES.txt`. The important part for this app is that a signed-in user can read their own `users/{uid}` document so the app can verify the role.

## 5. App behavior

- **Shop** → no email/password; the app signs in anonymously with Firebase.
- **Admin** → Firebase Email/Password + Firestore role `admin`.
- **Storekeeper** → Firebase Email/Password + Firestore role `storekeeper`.
- Staff users get a `🔐 Password` button to change their Firebase password after re-authentication.
- `Logout` signs the Firebase session out and reloads the app.
- Existing order form, saved orders, password-protected shared order behavior, camera/photo handling, and auto-update logic are preserved.

