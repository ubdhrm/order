# HB Store Hub Android

Separate Android app identity for the H.B Store order workflow.

## Important changes
- App name: **HB Store Hub**
- Android application ID: `com.hbstore.hub`
- New launcher icon (HB clipboard/check)
- Auto-update checks the latest release of github.com/ubdhrm/order (repo must be public).
- This app does not fetch or prompt for the old `OrderSlip v29` release.
- Shopkeeper login opens the 3-shop dashboard:
  - H.B MALL
  - H.B KHARTHIYATH
  - H.B SOUQ
- Each shop has its own pending-order list.
- Orders open as a checklist and can be completed.
- Firebase project remains `hb-order-slip` for the cloud order/auth workflow.

## Order status flow
- **Pending** - shop sent the order.
- **Noted** - storekeeper opened it (shop gets a notification).
- **Completed** - storekeeper completed it (shop gets a notification).
- Storekeeper also gets a notification for every new order.
- Android back button steps back inside the storekeeper screens (order -> shop orders -> shops) instead of closing the app.
- Notifications now come from a background service (OrderWatchService, checks about every 45 s), so they arrive even when the app is closed. Allow notifications and "no battery restriction" when asked.
- New order from a shop: if an older order of the same shop was never sent, or was sent but not completed, the app asks whether to add the new items to it (Yes = merge, No = new order).


## v1.0.36 UI fixes
- Saved Orders no longer shows a Send/Sent action; only Open and Delete are available.
- PENDING / NOTED / COMPLETED is displayed as a prominent status block.
- Opening a saved order enters the New-order editor; Back / ← New stays on the New tab.
- Background watcher notification is explicitly silent/minimal.
- Refreshed HB Store Hub launcher and notification icons.
