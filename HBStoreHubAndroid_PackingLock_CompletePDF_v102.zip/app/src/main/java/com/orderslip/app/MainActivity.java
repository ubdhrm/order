package com.orderslip.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.content.Context;
import android.webkit.MimeTypeMap;
import android.widget.Toast;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.ViewGroup;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;

public class MainActivity extends Activity {
    static volatile boolean inForeground = false;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER = 1001;
    private static final int CAMERA_CAPTURE = 1002;
    private static final int CAMERA_PERMISSION = 1003;
    private Uri cameraUri;
    private boolean updateCheckRunning = false;
    private boolean updateDialogShown = false;
    private File pendingInstallApk;
    private static final String UPDATE_PAGE = "https://github.com/ubdhrm/order/releases/latest";
    private static final String UPDATE_APK_URL = "https://github.com/ubdhrm/order/releases/latest/download/HBStoreHub.apk";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        // v1.0.50: background sync uses WorkManager, not a foreground service.
        // Stop any watcher left over from an older app version.
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return false; }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                // Android WebView does not always expose the HTML capture="environment"
                // flag consistently. Show our own image chooser so both Camera and Gallery
                // work reliably inside the APK.
                showImageChooser();
                return true;
            }
        });
        webView.addJavascriptInterface(new ShareBridge(this), "AndroidShare");
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#123B47"));
        root.addView(webView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        // Keep the page below the status bar even if the system draws edge-to-edge.
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(0, insets.getSystemWindowInsetTop(), 0, 0);
            return insets;
        });
        setContentView(root);
        webView.loadUrl("file:///android_asset/index.html");
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1004);
        }
        // Do not compete with the first screen render; check for updates shortly after startup.
        new Handler(Looper.getMainLooper()).postDelayed(() -> checkForUpdate(), 1500);
    }

    @Override protected void onPause() {
        inForeground = false;
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        inForeground = true;
        if (pendingInstallApk != null && pendingInstallApk.exists()) {
            if (Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls()) {
                installApk(pendingInstallApk);
            }
        }
        if (!updateCheckRunning && !updateDialogShown) checkForUpdate();
    }

    private void checkForUpdate() { checkForUpdate(false); }

    /**
     * Check GitHub's latest release without relying on the GitHub API.
     * The API is rate-limited for unauthenticated devices and can return HTTP 403.
     * /releases/latest redirects to the current release page, so we use that redirect
     * (and the page HTML as a fallback) to discover the vNN release number.
     */
    void checkForUpdate(final boolean manual) {
        if (updateCheckRunning) {
            if (manual) Toast.makeText(this, "Already checking...", Toast.LENGTH_SHORT).show();
            return;
        }
        updateCheckRunning = true;
        if (manual) Toast.makeText(this, "Checking for update...", Toast.LENGTH_SHORT).show();

        new Thread(() -> {
            String problem = null;
            int remoteCode = 0;
            String releaseName = "New version";
            String apkUrl = null;
            try {
                // Do not use api.github.com here: normal phones frequently get HTTP 403
                // from the unauthenticated API rate limit. GitHub's public latest-release
                // page is not subject to that API limit.
                HttpURLConnection c = (HttpURLConnection) new URL(UPDATE_PAGE).openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(15000);
                c.setInstanceFollowRedirects(true);
                c.setRequestProperty("User-Agent", "HB-Store-Hub-Android/1.0");
                c.setRequestProperty("Accept", "text/html,application/xhtml+xml");
                int code = c.getResponseCode();
                if (code < 200 || code >= 400) throw new Exception("GitHub release page HTTP " + code);

                String finalUrl = c.getURL() == null ? "" : c.getURL().toString();
                InputStream in = c.getInputStream();
                java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                in.close();
                c.disconnect();
                String html = out.toString("UTF-8");

                // The final URL normally is .../releases/tag/v37. If a redirect is
                // hidden by a proxy, inspect the release page for the same canonical tag link.
                java.util.regex.Matcher tagMatcher = java.util.regex.Pattern
                        .compile("/releases/tag/v([0-9]+)")
                        .matcher(finalUrl + "\n" + html);
                if (tagMatcher.find()) {
                    remoteCode = Integer.parseInt(tagMatcher.group(1));
                }
                if (remoteCode <= 0) throw new Exception("Could not determine latest release version");

                releaseName = "HB Store Hub v1.0." + remoteCode;
                // Stable GitHub latest-release asset URL. GitHub redirects this to the
                // actual asset of the latest release.
                apkUrl = UPDATE_APK_URL;
            } catch (Exception e) {
                problem = e.getMessage();
            }

            final int rc = remoteCode;
            final String release = releaseName;
            final String url = apkUrl;
            final String prob = problem;
            runOnUiThread(() -> {
                int installedCode = installedVersionNumber();
                if (prob == null && rc > installedCode && url != null) {
                    showUpdateDialog(rc, release, url);
                } else if (manual) {
                    String msg;
                    if (prob != null) msg = prob;
                    else if (rc <= installedCode) msg = "You have the latest version (" + BuildConfig.VERSION_NAME + ").";
                    else msg = "A newer release was found, but its APK could not be located.";
                    new AlertDialog.Builder(this)
                            .setTitle(prob == null ? "No update needed" : "Update check failed")
                            .setMessage(msg)
                            .setPositiveButton("OK", null)
                            .show();
                }
            });
            updateCheckRunning = false;
        }).start();
    }

    /** BuildConfig.VERSION_CODE can be different from the release tag when building locally. */
    private int installedVersionNumber() {
        try {
            java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile("(?:^|\\.)([0-9]+)$")
                    .matcher(BuildConfig.VERSION_NAME == null ? "" : BuildConfig.VERSION_NAME);
            if (m.find()) return Integer.parseInt(m.group(1));
        } catch (Exception ignored) {}
        return BuildConfig.VERSION_CODE;
    }

    private void showUpdateDialog(int remoteCode, String releaseName, String apkUrl) {
        if (isFinishing() || updateDialogShown) return;
        updateDialogShown = true;
        new AlertDialog.Builder(this)
                .setTitle("New update available")
                .setMessage(releaseName + " is ready.\n\nCurrent version: " + BuildConfig.VERSION_NAME + "\nNew version: " + remoteCode + "\n\nUpdate now?")
                .setCancelable(false)
                .setNegativeButton("Later", (d, w) -> { updateDialogShown = false; })
                .setPositiveButton("Update", (d, w) -> downloadAndInstallUpdate(apkUrl))
                .show();
    }

    private void downloadAndInstallUpdate(String apkUrl) {
        Toast.makeText(this, "Downloading update...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            File dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "updates");
            if (!dir.exists()) dir.mkdirs();
            File apk = new File(dir, "HBStoreHub-update.apk");
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(apkUrl).openConnection();
                c.setConnectTimeout(10000); c.setReadTimeout(30000);
                c.setInstanceFollowRedirects(true);
                c.setRequestProperty("User-Agent", "HB-Store-Hub-Android");
                if (c.getResponseCode() != 200) throw new Exception("Download HTTP " + c.getResponseCode());
                InputStream in = c.getInputStream();
                FileOutputStream fos = new FileOutputStream(apk);
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) != -1) fos.write(buf, 0, n);
                fos.close(); in.close(); c.disconnect();
                runOnUiThread(() -> {
                    Toast.makeText(this, "Update downloaded", Toast.LENGTH_SHORT).show();
                    pendingInstallApk = apk;
                    installApk(apk);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    updateDialogShown = false;
                    new AlertDialog.Builder(this).setTitle("Update failed")
                            .setMessage("Could not download the new version. Please try again later.")
                            .setPositiveButton("OK", null).show();
                });
            }
        }).start();
    }

    private void installApk(File apk) {
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            new AlertDialog.Builder(this)
                    .setTitle("Allow app updates")
                    .setMessage("Android needs permission to install updates from this app. Enable it, then return here to continue the update.")
                    .setPositiveButton("Open Settings", (d, w) -> {
                        try {
                            Intent i = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()));
                            startActivity(i);
                        } catch (Exception e) { startActivity(new Intent(Settings.ACTION_SECURITY_SETTINGS)); }
                    })
                    .setNegativeButton("Later", null).show();
            return;
        }
        try {
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", apk);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Unable to open installer", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    results = new Uri[n];
                    for (int i = 0; i < n; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            if (fileCallback != null) { fileCallback.onReceiveValue(results); fileCallback = null; }
        } else if (requestCode == CAMERA_CAPTURE) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && cameraUri != null) results = new Uri[]{cameraUri};
            if (fileCallback != null) { fileCallback.onReceiveValue(results); fileCallback = null; }
            cameraUri = null;
        }
    }

    private void showImageChooser() {
        final String[] choices = new String[]{"📷 Camera", "🖼 Gallery"};
        new AlertDialog.Builder(this)
                .setTitle("Add photo")
                .setItems(choices, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) startCamera(); else openPicker();
                    }
                })
                .setOnCancelListener(dialog -> cancelFileChooser())
                .show();
    }

    private void openPicker() {
        try {
            Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            pick.addCategory(Intent.CATEGORY_OPENABLE);
            pick.setType("image/*");
            pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
            startActivityForResult(pick, FILE_CHOOSER);
        } catch (Exception e) {
            // Some devices do not provide ACTION_OPEN_DOCUMENT; fall back to GET_CONTENT.
            try {
                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("image/*");
                startActivityForResult(pick, FILE_CHOOSER);
            } catch (Exception ignored) { cancelFileChooser(); }
        }
    }

    private void cancelFileChooser() {
        if (fileCallback != null) {
            fileCallback.onReceiveValue(null);
            fileCallback = null;
        }
    }

    private void startCamera() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION);
            return;
        }
        launchCamera();
    }

    private void launchCamera() {
        try {
            File dir = new File(getCacheDir(), "camera");
            if (!dir.exists()) dir.mkdirs();
            File photo = new File(dir, "photo_" + System.currentTimeMillis() + ".jpg");
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", photo);
            Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            cam.setClipData(ClipData.newRawUri("", cameraUri));
            cam.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            startActivityForResult(cam, CAMERA_CAPTURE);
        } catch (Exception e) {
            openPicker();   // no camera app -> let the user pick a photo instead
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) launchCamera();
            else openPicker();
        }
    }

    @Override public void onBackPressed() {
        // Let the page go one step back first (order -> shop orders -> shops); close the app only from the top screen.
        webView.evaluateJavascript(
                "(function(){try{return !!(window.hbHandleBack && window.hbHandleBack());}catch(e){return false;}})()",
                value -> {
                    if ("true".equals(value)) return;
                    if (webView.canGoBack()) webView.goBack(); else finish();
                });
    }
}
