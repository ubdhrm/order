# Firebase setup for HB Store Hub

Project: `hb-order-slip`
Android package: `com.hbstore.app`

## 1. Authentication

Firebase Console → Build → Authentication → Sign-in method:

- Enable **Email/Password** for Admin and Storekeeper.
- Enable **Anonymous** for Shop entry.

The app uses the Firebase Web SDK inside the existing WebView, so the existing HB Store Hub UI/features remain intact.

## 2. Admin user

Create the Admin user under Authentication → Users. Example used during setup:

- Email: `ubd343@hb.com`
- Password: the password you set in Firebase

Then Firestore → `users` → document ID must be the Admin Firebase **UID**, with:

- `role`: `admin`
- `name`: `Admin` (optional)

## 3. Storekeeper user

Create another Email/Password user, then create `users/{UID}` with:

- `role`: `storekeeper`
- `name`: `Storekeeper` (optional)

## 4. Firestore rules

Use the rules in `FIREBASE_FIRESTORE_RULES.txt`. The important part for this app is that a signed-in user can read their own `users/{uid}` document so the app can verify the role.

## 5. Storekeeper order dashboard

After Storekeeper login, the app opens a separate checklist dashboard instead of the New Order screen. The three shops are kept separate:

- H.B MALL
- H.B KHARTHIYATH
- H.B SOUQ

Each shop card shows its pending order count. Tapping a shop opens only that shop's orders; tapping an order opens the checklist. Checking items and saving updates the Firestore order. **Complete order** marks it completed and removes it from the pending dashboard.

Shops send orders to the `orders` Firestore collection from inside the app; WhatsApp is not required for the normal Android workflow.

## 6. App behavior

- **Shop** → no email/password; the app signs in anonymously with Firebase.
- **Admin** → Firebase Email/Password + Firestore role `admin`.
- **Storekeeper** → Firebase Email/Password + Firestore role `storekeeper`.
- Staff users get a `🔐 Password` button to change their Firebase password after re-authentication.
- `Logout` signs the Firebase session out and reloads the app.
- Existing order form, saved orders, password-protected shared order behavior, camera/photo handling, and auto-update logic are preserved.


## Storekeeper screen

The Storekeeper role opens a separate in-app dashboard instead of the New Order form. It has three separate shop cards: **H.B MALL**, **H.B KHARTHIYATH**, and **H.B SOUQ**. Each card shows its own pending-order count. Opening a shop shows only that shop's orders; opening an order shows the checklist. Saving the checklist updates Firestore, and **Complete order** marks the order completed and removes it from the pending list.

In the Android app, Shop orders are submitted to Firestore (`orders`) instead of requiring WhatsApp.


## Cross-device shop history
Shop orders are filtered by the stable `shopName`, not the anonymous Firebase UID. The app writes the selected shop into the shop user's Firestore profile. This keeps sent orders visible after uninstall/reinstall or moving the same shop to another phone. Unsent local drafts remain device-local.
