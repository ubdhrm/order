# HB Store Hub Android

Separate Android app identity for the H.B Store order workflow.

## Important changes
- App name: **HB Store Hub**
- Android application ID: `com.hbstore.hub`
- New launcher icon (HB clipboard/check)
- Auto-update checks the public GitHub latest-release page (no GitHub API token required), avoiding API HTTP 403/rate-limit failures.
- This app does not fetch or prompt for the old `OrderSlip v29` release.
- Shopkeeper login opens the 3-shop dashboard:
  - H.B MALL
  - H.B KHARTHIYATH
  - H.B SOUQ
- Each shop has its own pending-order list.
- Orders open as a checklist and can be completed.
- Firebase project remains `hb-order-slip` for the cloud order/auth workflow.

## Order status flow
- **Pending** - shop sent the order.
- **Checked** - storekeeper opened it (shop gets a notification).
- **Completed** - storekeeper completed it (shop gets a notification).
- Storekeeper also gets a notification for every new order.
- Android back button steps back inside the storekeeper screens (order -> shop orders -> shops) instead of closing the app.
- Background order/status sync uses Android WorkManager without a persistent foreground-service notification. Actual order notifications may still be shown when a change is detected.
- New order from a shop: if an older order of the same shop was never sent, or was sent but not completed, the app asks whether to add the new items to it (Yes = merge, No = new order).


## v1.0.36 UI fixes
- Saved Orders no longer shows a Send/Sent action; only Open and Delete are available.
- PENDING / CHECKED / COMPLETED is displayed as a prominent status block.
- Opening a saved order enters the New-order editor; Back / ← New stays on the New tab.
- There is no persistent background-watcher notification.
- Refreshed HB Store Hub launcher and notification icons.

## v1.0.40 fixes
- Auto-update no longer depends on `api.github.com`; it follows GitHub's `/releases/latest` redirect and downloads `HBStoreHub.apk` from the latest release.
- Update comparison uses the numeric suffix of `versionName`, so a locally built `1.0.x` release cannot be miscompared with a different Gradle `versionCode`.
- GitHub Actions now auto-builds and publishes a new GitHub Release whenever code is pushed to `main` or `master`; manual `workflow_dispatch` is still available.
- Automatic release tags continue from the highest existing `vNN` tag, so the next build after v38 becomes v39.
- Storekeeper shop cards highlight **Pending** orders as the main number; total historical orders are no longer the main highlight. Checked and Completed remain secondary counts.

- Shop Saved Orders sync only the current installation's submitted orders. Unsent drafts remain local to the device; reinstalling creates a new anonymous shop identity and does not pull old cloud history.


## v1.0.46 cloud sync / notifications / admin cleanup
- Shop Saved Orders uses the Firestore snapshot as the source of truth for submitted orders; admin cloud deletion now removes the same orders from the Shop Saved list.
- Shop status synchronization is based on stable `shopName`, so Pending → Checked → Completed does not get stuck after reinstall.
- Background order notifications are started after Firebase login and restored after reboot/app update; the native watcher also resolves the shop by stable `shopName` instead of the reinstall-sensitive anonymous UID.
- Added Admin → Cloud Orders management with shop-wise permanent deletion. Deleting a shop's orders removes them from Firestore, Storekeeper, and Shop on their next sync.


## v1.0.48 shop saved/sync fix
- Removed the Shop selector from the Saved tab. The Saved tab uses the shop selected on the New-order screen and never mixes saved orders from another shop.
- Shop cloud sync now queries orders by the stable Admin-assigned `shopName`, so orders created by older app/login UIDs remain visible after an app update or re-login. Firestore rules must be deployed from `FIREBASE_FIRESTORE_RULES.txt` so shops can read their own orders by `shopName`.
- Local Saved Orders are filtered to the current shop.
- Shop reinstall intentionally starts with a new anonymous UID; old cloud orders from the removed installation are not pulled into the new installation.


## v1.0.50 background sync
- Background order/status sync uses Android WorkManager instead of a foreground service.
- No persistent “Watching for order updates” notification is shown.
- An immediate one-time sync is scheduled after login, followed by periodic background sync when network is available.
- While the app is open, Firestore listeners continue to provide live updates.
- Actual order update notifications are still allowed; only the persistent service-running notification is removed.


## v1.0.57 shop picker + locked shop
- Shop tab on the login screen now has a **Select your shop** dropdown (H.B MALL / H.B KHARTHIYATH / H.B SOUQ). No ID or password for shops.
- The first entry locks this phone (Firebase anonymous UID) to that shop: `users/{uid}.shopName`. Next launches go straight in.
- The New Order screen shows the shop as locked (read-only). **Request shop change** sends `users/{uid}.changeRequest` to Admin.
- Admin dashboard → **Shop change requests** → Approve (updates `shopName`; the shop phone reloads into the new shop) or Reject.
- Firestore rules updated: a shop can no longer change its own `shopName`; Admin can read `users`. **Publish the new FIREBASE_FIRESTORE_RULES.txt.**
- Note: reinstalling the app creates a new anonymous UID, so the phone is asked to pick a shop again.

## v1.0.58 shop completed-order view
- Completed orders opened from the Shop's Saved tab now show a clean read-only summary: "Order completed" banner with counts, one card per item (name, qty + unit, ✓ Checked / ✕ Out of stock), size rows for sized items, the shop's own note, storekeeper note only if one was written, and the item photo if any.
- No editable-looking Qty/Unit boxes and no empty "Your notes (storekeeper only)" box.
- Storekeeper screens and Cancelled orders are unchanged.

## v1.0.59 faster start for locked shop phones
- A phone already locked to a shop enters straight away using the cached shop (no Firestore read before opening), and the login card is hidden while Firebase starts, so the "Select your shop" screen no longer shows for ~4 seconds.
- The shop is still verified with Firestore in the background; if Admin approved a change or removed the profile, the app reloads accordingly.

## v1.0.60 faster start for Admin / Storekeeper
- After a successful staff login the role is cached on the phone. Next launches open the Admin / Storekeeper screen straight away (login card hidden while Firebase starts).
- The role is re-checked with Firestore in the background; if it was changed or removed, the app reloads or signs out.
- Logout clears the cache.

## v1.0.61 New arrivals popup
- Admin dashboard → **New arrivals popup**: create a popup with title, details text and up to 4 photos; preview it; publish; hide/show or delete published ones.
- Shops see unseen popups full screen right after opening the app (one after another, "Next"/"Close"). The ✕ or Android Back closes it. A popup is shown once per phone; a **New arrivals** button under the shop field reopens any visible popup.
- Data is stored in the Firestore `announcements` collection (photos compressed and stored inside the document). **Publish the updated FIREBASE_FIRESTORE_RULES.txt** (adds `announcements`: read for signed-in users, write for Admin only).

## v1.0.62 popup shows every time
- New-arrivals popups now show **every time the shop opens the app** until Admin hides or deletes them.
- Admin form has "Show only once per phone" (off by default) for popups that should appear a single time.
- The shop's New arrivals button still reopens any visible popup at any time.

## v1.0.63 Storekeeper can manage New arrivals
- Storekeeper dashboard has an **🆕 Arrivals** button opening the same create / preview / hide / delete screen as Admin.
- Firestore rules for `announcements`: read for signed-in users, write for Admin **and Storekeeper**. Publish the updated rules.
- Storekeeper does not get the popup itself; only Shops do.

## v1.0.64 start-up logo + About us
- While the app starts (instead of a blank cream screen) the HB logo is shown centred.
- Shop → Saved tab, at the very bottom (below Check for update / Send feedback): **About us** screen with "What is this app for?", "How it works", "App features" and "Created by UBAID".
- Android Back closes the About screen.

## v1.0.65 delivery confirmation ("Sending…")
- After Send, the order shows **Sending…** until Firebase confirms it received the order. Only then it becomes **Sent · waiting** (was "Pending"), then Checked / Completed.
- If the app is closed before confirmation, the order shows **Checking…** on next start and is verified against the cloud. If it is really not in the cloud it shows **Not sent** with **Send again** / **Delete**.
- The New form is reset as soon as Send starts (no double-send); the order lives in Saved while sending. If sending fails it goes back to Draft.
- Orders sent by older versions are unaffected.

## v1.0.68 Admin can no longer add orders
- The "Add order" button is removed from the Admin screen. Orders can only be created by shops.

## v1.0.67 Add-order safety: shop must be selected, duplicate warning, order origin stamp
- Admin "Add order": shop dropdown now starts on "Select shop" (before, the first shop was silently pre-selected).
- Admin "Add order": warns if the exact same items were already sent to any shop in the last 24h.
- Every new order now records createdVia (admin-add / shop-app), createdByUid and createdByRole; the Admin order list shows "added by admin" or "from shop phone".

## v1.0.66 sent orders are view-only + add / remove items
- Opening a **sent** order (Waiting for storekeeper / Checked) from Saved now shows a **view-only screen** (no editable form, no Send button), so it can no longer create a duplicate order.
- On that screen: **＋ Add item**, **Remove** (per item, even if the storekeeper already checked it) and **Cancel order**.
- **Add item** opens the normal item form in "Adding items to Order #N" mode; the items are appended to the SAME cloud order (same order ID). Items show **Sending…** until Firebase confirms, or **Not sent** with **Send again** / **Discard**. Adding is idempotent (an item ID is never added twice).
- **Remove** only flags the item (`removedByShop`), never deletes it. The shop sees "Removed by you"; the storekeeper sees a **REMOVED BY SHOP** card (red "put it back in stock" if it was already checked, grey otherwise) and a notification. Removed items do not block **Complete**.
- Each item shows its own status: Sending… / Waiting for storekeeper / Checked / Out of stock / Removed by you.
- Status wording: "Sent · waiting" is now **Waiting for storekeeper**.
- Completed and Cancelled orders are locked (no Add / Remove / Cancel); the list no longer shows Cancel on them.
- No Firestore rules change needed.


## Admin Control Center — functional implementation
The Admin redesign now includes Firebase-backed:
- Dashboard counts from live `orders` and `feedback`
- Shop list and order status summaries
- Order search/filter and permanent delete
- Real staff login creation (Admin/Storekeeper) using a secondary Firebase Auth app
- Staff role and active/disabled profile management
- Reports calculated from live orders
- Real Admin activity audit log in `activityLog`
- Firebase-persisted Admin settings in `settings/admin`
- Announcement publish/toggle/delete actions recorded in the audit log

### Firestore rules
Deploy the updated `FIREBASE_FIRESTORE_RULES.txt` in Firebase Console / Firestore Rules. The new rules add Admin-only access for `activityLog` and `settings`.

## Startup speed: instant dashboard from cached login
- The app no longer waits for the Firebase Auth SDK to finish restoring its own session before showing the dashboard. If this phone has a verified identity cached from a past login, it opens straight to that dashboard immediately and the real Firebase Auth check runs quietly behind it, correcting course (back to the login card) only if that trust turns out to be wrong.
- For a Shop login, the live Firestore order listener now starts at the same time as the cached dashboard, instead of waiting for Firebase's session restore to confirm the account first.
- Firebase SDK files (`firebase-app-compat.js`, `firebase-auth-compat.js`, `firebase-firestore-compat.js`) are now bundled into the APK's assets at build time (`fetchFirebaseSdk` Gradle task, pinned to `10.14.1`) instead of being downloaded and cached to disk on first run, removing a network dependency from cold start and reinstalls entirely.
