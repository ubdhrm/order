package com.orderslip.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import androidx.core.app.NotificationCompat;

/** Small helper that shows the "order updates" notifications. */
final class OrderNotifier {
    static final String CHANNEL_UPDATES = "order_updates";
    static final String CHANNEL_WATCH = "order_watch_silent_v2";

    private OrderNotifier() {}

    static void ensureChannels(Context ctx) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel updates = new NotificationChannel(CHANNEL_UPDATES, "Order updates", NotificationManager.IMPORTANCE_HIGH);
        updates.setDescription("New orders and order status changes");
        nm.createNotificationChannel(updates);
        NotificationChannel watch = new NotificationChannel(CHANNEL_WATCH, "Background connection", NotificationManager.IMPORTANCE_MIN);
        watch.setDescription("Silent background connection for order notifications");
        watch.setSound(null, null);
        watch.enableVibration(false);
        watch.setShowBadge(false);
        nm.createNotificationChannel(watch);
    }

    static PendingIntent openAppIntent(Context ctx) {
        Intent open = new Intent(ctx, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(ctx, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static Bitmap largeCache;
    /** Full-colour HB app icon shown on the right of each notification. */
    private static Bitmap largeIcon(Context ctx) {
        try {
            if (largeCache == null) largeCache = BitmapFactory.decodeResource(ctx.getResources(), R.drawable.ic_notif_large);
        } catch (Exception ignored) {}
        return largeCache;
    }

    /** Always shows the notification. */
    static void show(Context ctx, String title, String body) {
        try {
            ensureChannels(ctx);
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, CHANNEL_UPDATES)
                    .setSmallIcon(R.drawable.ic_stat_notify)
                    .setColor(0xFF005F5A)
                    .setLargeIcon(largeIcon(ctx))
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setDefaults(NotificationCompat.DEFAULT_ALL)
                    .setAutoCancel(true)
                    .setContentIntent(openAppIntent(ctx));
            nm.notify((int) (System.currentTimeMillis() & 0x7fffffff), b.build());
        } catch (Exception ignored) {
            // Notifications must never crash the app.
        }
    }

    /** Skips the notification while the app is on screen (the page shows its own message then). */
    static void showUnlessForeground(Context ctx, String title, String body) {
        if (MainActivity.inForeground) return;
        show(ctx, title, body);
    }
}
