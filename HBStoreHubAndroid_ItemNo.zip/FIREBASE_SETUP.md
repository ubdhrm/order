# Firebase setup for HB Store Hub

Project: `hb-order-slip`
Android package: `com.hbstore.app`

## 1. Authentication

Firebase Console → Build → Authentication → Sign-in method:

- Enable **Email/Password**. Admin, Storekeeper, and every Shop now sign in this way — each shop gets its own fixed email+password account instead of the old anonymous, phone-locked entry.
- **Anonymous** sign-in is no longer used by the app and can be left disabled.

The app uses the Firebase Web SDK inside the existing WebView, so the existing HB Store Hub UI/features remain intact.

## 2. Admin user

Create the Admin user under Authentication → Users. Example used during setup:

- Email: `ubd343@hb.com`
- Password: the password you set in Firebase

Then Firestore → `users` → document ID must be the Admin Firebase **UID**, with:

- `role`: `admin`
- `name`: `Admin` (optional)

## 3. Storekeeper user

Create another Email/Password user, then create `users/{UID}` with:

- `role`: `storekeeper`
- `name`: `Storekeeper` (optional)

## 4. Shop logins

Shops no longer pick their name from a dropdown on the phone — each shop now has its own fixed Firebase Email/Password account, created from inside the app:

- Log in as **Admin** → **🔑 Shop logins** → pick the shop, enter an email + password for it, **Create login**.
- This creates the Firebase Auth account and its `users/{uid}` Firestore profile (`role: 'shop'`, `shopName: ...`) in one step — you don't need to touch the Firebase Console for this.
- Give that email + password to the shop. Whatever phone they log in on (even after a reset, reinstall, or app clone) gets that shop's identity — it's tied to the account, not the phone's local storage.
- **Remove access** on that screen deletes the shop's Firestore profile (it signs the shop out immediately if it's logged in). The Firebase Auth account itself still needs to be deleted from the Console if it should stop being able to sign in at all.

## 5. Firestore rules

Use the rules in `FIREBASE_FIRESTORE_RULES.txt`. The important part for this app is that a signed-in user can read their own `users/{uid}` document so the app can verify the role, and that Admin can create/update/delete any `users/{uid}` document (needed for the Shop logins screen above).

## 6. Storekeeper order dashboard

After Storekeeper login, the app opens a separate checklist dashboard instead of the New Order screen. The three shops are kept separate:

- H.B MALL
- H.B KHARTHIYATH
- H.B SOUQ

Each shop card shows its pending order count. Tapping a shop opens only that shop's orders; tapping an order opens the checklist. Checking items and saving updates the Firestore order. **Complete order** marks it completed and removes it from the pending dashboard.

Shops send orders to the `orders` Firestore collection from inside the app; WhatsApp is not required for the normal Android workflow.

## 7. App behavior

- **Shop** → Firebase Email/Password (its own fixed account, created by Admin) + Firestore role `shop`.
- **Admin** → Firebase Email/Password + Firestore role `admin`.
- **Storekeeper** → Firebase Email/Password + Firestore role `storekeeper`.
- All three roles get a `🔐 Password` button to change their own Firebase password after re-authentication.
- `Logout` signs the Firebase session out and reloads the app.
- Existing order form, saved orders, password-protected shared order behavior, camera/photo handling, and auto-update logic are preserved.


## Storekeeper screen

The Storekeeper role opens a separate in-app dashboard instead of the New Order form. It has three separate shop cards: **H.B MALL**, **H.B KHARTHIYATH**, and **H.B SOUQ**. Each card shows its own pending-order count. Opening a shop shows only that shop's orders; opening an order shows the checklist. Saving the checklist updates Firestore, and **Complete order** marks the order completed and removes it from the pending list.

In the Android app, Shop orders are submitted to Firestore (`orders`) instead of requiring WhatsApp.


## Cross-device shop history
Shop orders are filtered by the stable `shopName`, which now comes from that shop's own fixed Firebase account rather than a per-phone local lock. Logging in with the same shop email on any phone (after a reset, reinstall, or a different device entirely) always resumes that shop's own order history. Unsent local drafts remain device-local.


## Admin cloud order deletion
The Admin role has a Cloud Orders screen with one permanent delete action per shop. It deletes every `orders` document whose `shopName` matches that shop. Firestore rules allow only Admin to delete orders. Storekeeper and Shop receive the deletion through their next live snapshot, so the order is removed from both views.
