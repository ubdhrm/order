package com.orderslip.app;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import org.json.JSONArray;
import org.json.JSONObject;

/** Background Firestore sync without a foreground service or persistent running notification. */
public class OrderSyncWorker extends Worker {
    static final String PREFS = "hb_watch";
    private static final String API_KEY = "AIzaSyCkYisLrdqcKsiCINNbEuvrBomY41Rl8kI";
    private static final String DOCS = "https://firestore.googleapis.com/v1/projects/hb-order-slip/databases/(default)/documents";
    private String idToken;
    private long idTokenExpiry;

    public OrderSyncWorker(@NonNull Context context, @NonNull WorkerParameters params) { super(context, params); }

    @NonNull @Override public Result doWork() {
        SharedPreferences sp=getApplicationContext().getSharedPreferences(PREFS,Context.MODE_PRIVATE);
        String role=sp.getString("role","");
        if(role.isEmpty()||sp.getString("refreshToken","").isEmpty()) return Result.success();
        try { if("storekeeper".equals(role)) pollStorekeeper(sp); else if("shop".equals(role)) pollShop(sp); return Result.success(); }
        catch(Exception e){ return Result.retry(); }
    }

    private void pollShop(SharedPreferences sp)throws Exception{
        String uid=sp.getString("uid",""); if(uid.isEmpty()){sp.edit().remove("shopMap").apply();return;}
        String token=getIdToken(sp); JSONObject q=new JSONObject();
        q.put("from",new JSONArray().put(new JSONObject().put("collectionId","orders")));
        q.put("select",projection("status","orderNo","shopName","shopUid"));
        // Firestore rules let a shop read orders only by its own shopName (not by shopUid),
        // so look up the Admin-assigned shopName from the user's profile first.
        JSONObject prof=new JSONObject(http("GET",DOCS+"/users/"+uid,null,null,token));
        String myShop=str(prof.optJSONObject("fields"),"shopName"); if(myShop.isEmpty()) return;
        q.put("where",fieldFilter("shopName","EQUAL",new JSONObject().put("stringValue",myShop)));
        JSONArray res; try{ res=runQuery(token,q); }catch(Exception ex){ q.put("where",fieldFilter("shopUid","EQUAL",new JSONObject().put("stringValue",uid))); res=runQuery(token,q); } Map<String,String[]> cur=new HashMap<>();
        for(int i=0;i<res.length();i++){JSONObject d=res.getJSONObject(i).optJSONObject("document");if(d==null)continue;JSONObject f=d.optJSONObject("fields");cur.put(idOf(d.optString("name")),new String[]{str(f,"status"),str(f,"orderNo")});}
        String pj=sp.getString("shopMap",null); JSONObject prev=pj==null?null:new JSONObject(pj), next=new JSONObject(); Context ctx=getApplicationContext();
        for(Map.Entry<String,String[]> e:cur.entrySet()){next.put(e.getKey(),new JSONObject().put("s",e.getValue()[0]).put("n",e.getValue()[1]));if(prev!=null){JSONObject p=prev.optJSONObject(e.getKey());String now=e.getValue()[0];if(p!=null&&"pending".equals(p.optString("s"))&&"accepted".equals(now))OrderNotifier.show(ctx,"Order checked",label(e.getValue()[1])+" has been checked by the storekeeper");if(p!=null&&!"completed".equals(p.optString("s"))&&"completed".equals(now))OrderNotifier.show(ctx,"Order completed ✓",label(e.getValue()[1])+" has been completed");if(p!=null&&!"cancelled_by_shop".equals(p.optString("s"))&&"cancelled_by_shop".equals(now))OrderNotifier.show(ctx,"Order cancelled",label(e.getValue()[1])+" was cancelled by the shop");}}
        sp.edit().putString("shopMap",next.toString()).apply();
    }

    private void pollStorekeeper(SharedPreferences sp)throws Exception{
        String token=getIdToken(sp), last=sp.getString("skLast",null);if(last==null)last=isoNow(-60000L);long lastKey=tsKey(last);
        JSONObject q=new JSONObject();q.put("from",new JSONArray().put(new JSONObject().put("collectionId","orders")));q.put("select",projection("status","orderNo","shopName","createdAt","updatedAt","addedAt"));q.put("where",fieldFilter("updatedAt","GREATER_THAN",new JSONObject().put("timestampValue",last)));JSONArray res=runQuery(token,q);
        Set<String> seen=new LinkedHashSet<>();JSONArray sa=new JSONArray(sp.getString("skSeen","[]"));for(int i=0;i<sa.length();i++)seen.add(sa.getString(i));Set<String> cancelSeen=new LinkedHashSet<>();JSONArray ca=new JSONArray(sp.getString("skCancelled","[]"));for(int i=0;i<ca.length();i++)cancelSeen.add(ca.getString(i));String maxTs=last;long maxKey=lastKey;List<String> fresh=new ArrayList<>(),updated=new ArrayList<>(),cancelled=new ArrayList<>();
        for(int i=0;i<res.length();i++){JSONObject d=res.getJSONObject(i).optJSONObject("document");if(d==null)continue;JSONObject f=d.optJSONObject("fields");String id=idOf(d.optString("name")),st=str(f,"status"),no=str(f,"orderNo"),shop=str(f,"shopName"),created=ts(f,"createdAt"),up=ts(f,"updatedAt"),added=ts(f,"addedAt");long uk=tsKey(up);if(uk>maxKey){maxKey=uk;maxTs=up;}String who=shop.isEmpty()?"A shop":shop;if("pending".equals(st)&&!seen.contains(id)&&tsKey(created)>lastKey){seen.add(id);fresh.add(who+" sent "+(no.isEmpty()?"a new order":"Order #"+no));}else if(!added.isEmpty()&&tsKey(added)>lastKey&&!"completed".equals(st)&&!"cancelled_by_shop".equals(st))updated.add(who+" added items to "+(no.isEmpty()?"an order":"Order #"+no));if("cancelled_by_shop".equals(st)&&!cancelSeen.contains(id)){cancelSeen.add(id);cancelled.add(who+" cancelled "+(no.isEmpty()?"an order":"Order #"+no));}}
        Context ctx=getApplicationContext();if(fresh.size()==1)OrderNotifier.showUnlessForeground(ctx,"New order",fresh.get(0));else if(fresh.size()>1)OrderNotifier.showUnlessForeground(ctx,"New orders",fresh.size()+" new orders received");if(updated.size()==1)OrderNotifier.showUnlessForeground(ctx,"Order updated",updated.get(0));else if(updated.size()>1)OrderNotifier.showUnlessForeground(ctx,"Orders updated","Shops added items to "+updated.size()+" orders");if(cancelled.size()==1)OrderNotifier.showUnlessForeground(ctx,"Order cancelled by shop",cancelled.get(0));else if(cancelled.size()>1)OrderNotifier.showUnlessForeground(ctx,"Orders cancelled by shop",cancelled.size()+" shop orders were cancelled");
        JSONArray out=new JSONArray();int skip=Math.max(0,seen.size()-300),idx=0;for(String s:seen)if(idx++>=skip)out.put(s);JSONArray co=new JSONArray();int cskip=Math.max(0,cancelSeen.size()-300),ci=0;for(String s:cancelSeen)if(ci++>=cskip)co.put(s);sp.edit().putString("skLast",maxTs).putString("skSeen",out.toString()).putString("skCancelled",co.toString()).apply();
    }

    private static String label(String n){return n==null||n.isEmpty()?"Your order":"Order #"+n;}
    private JSONArray runQuery(String token,JSONObject q)throws Exception{return new JSONArray(http("POST",DOCS+":runQuery",new JSONObject().put("structuredQuery",q).toString(),"application/json",token));}
    private static JSONObject projection(String...names)throws Exception{JSONArray a=new JSONArray();for(String n:names)a.put(new JSONObject().put("fieldPath",n));return new JSONObject().put("fields",a);}
    private static JSONObject fieldFilter(String field,String op,JSONObject value)throws Exception{return new JSONObject().put("fieldFilter",new JSONObject().put("field",new JSONObject().put("fieldPath",field)).put("op",op).put("value",value));}
    private static String idOf(String n){int i=n.lastIndexOf('/');return i>=0?n.substring(i+1):n;}
    private static String str(JSONObject f,String n){if(f==null)return"";JSONObject v=f.optJSONObject(n);return v==null?"":v.optString("stringValue","");}
    private static String ts(JSONObject f,String n){if(f==null)return"";JSONObject v=f.optJSONObject(n);return v==null?"":v.optString("timestampValue","");}
    private static long tsKey(String t){try{if(t==null||t.isEmpty())return 0L;if(t.endsWith("Z"))t=t.substring(0,t.length()-1);String main=t,frac="";int dot=t.indexOf('.');if(dot>=0){main=t.substring(0,dot);frac=t.substring(dot+1);}SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));long secs=f.parse(main).getTime()/1000L;StringBuilder sb=new StringBuilder(frac);while(sb.length()<9)sb.append('0');long nanos=Long.parseLong(sb.substring(0,9));return secs*1000000000L+nanos;}catch(Exception e){return 0L;}}
    private static String isoNow(long off){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new java.util.Date(System.currentTimeMillis()+off));}
    private String getIdToken(SharedPreferences sp)throws Exception{if(idToken!=null&&System.currentTimeMillis()<idTokenExpiry-60000L)return idToken;String body="grant_type=refresh_token&refresh_token="+URLEncoder.encode(sp.getString("refreshToken",""),"UTF-8");String res=http("POST","https://securetoken.googleapis.com/v1/token?key="+API_KEY,body,"application/x-www-form-urlencoded",null);JSONObject j=new JSONObject(res);idToken=j.getString("id_token");long ex=Long.parseLong(j.optString("expires_in","3600"));idTokenExpiry=System.currentTimeMillis()+ex*1000L;String nr=j.optString("refresh_token","");if(!nr.isEmpty())sp.edit().putString("refreshToken",nr).apply();return idToken;}
    private String http(String method,String url,String body,String type,String bearer)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();try{c.setRequestMethod(method);c.setConnectTimeout(15000);c.setReadTimeout(20000);if(bearer!=null)c.setRequestProperty("Authorization","Bearer "+bearer);if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type",type);OutputStream os=c.getOutputStream();os.write(body.getBytes("UTF-8"));os.close();}int code=c.getResponseCode();InputStream is=code>=400?c.getErrorStream():c.getInputStream();String text=readAll(is);if(code>=400)throw new IOException("HTTP "+code+" "+text);return text;}finally{c.disconnect();}}
    private static String readAll(InputStream is)throws IOException{if(is==null)return"";ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[4096];int n;while((n=is.read(b))!=-1)out.write(b,0,n);is.close();return out.toString("UTF-8");}
}
