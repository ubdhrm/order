package com.orderslip.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/** Restarts the background order watcher after the phone reboots or the app is updated. */
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        try {
            SharedPreferences sp = context.getSharedPreferences(OrderWatchService.PREFS, Context.MODE_PRIVATE);
            if (!sp.getString("refreshToken", "").isEmpty() && !sp.getString("role", "").isEmpty()) {
                OrderWatchService.start(context);
            }
        } catch (Exception ignored) {}
    }
}
