# Update channel summary

The Android app decides its GitHub update channel from the logged-in Firebase role:

| Firebase role | Update source |
|---|---|
| `admin` | Newest release, including `-test` prereleases |
| `shop` | Latest stable release only |
| `storekeeper` | Latest stable release only |

Test releases must be GitHub **prereleases**. Stable releases must be normal GitHub releases.
