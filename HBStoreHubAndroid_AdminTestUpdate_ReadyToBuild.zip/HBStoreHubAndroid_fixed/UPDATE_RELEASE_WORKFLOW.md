# Admin-only test update workflow

This project now uses two update channels:

- **Admin**: checks all GitHub releases, including prereleases such as `v69-test`.
- **Shop / Storekeeper**: checks only GitHub's latest stable release.

The Firebase `users/{uid}.role` value is used. No phone/device ID is stored.

## First setup

The GitHub Actions workflow needs these repository secrets:

- `KEYSTORE_BASE64` — base64 of the same `release-key.jks` used to sign the currently installed app.
- `KEYSTORE_PASSWORD` — keystore password.
- `KEY_ALIAS` — release key alias.

`KEYSTORE_BASE64` can be produced locally with:

```bash
base64 -w 0 release-key.jks
```

Do not commit the keystore or passwords to the repository.

## Test a new version

If the current installed stable version is 68, use a new tag such as:

```text
v69-test
```

Push the tag. GitHub Actions builds `1.0.69` and creates a **prerelease**.

- Admin account → sees v69-test and can update.
- Shop account → does not see v69-test and stays on stable v68.
- Storekeeper account → does not see v69-test and stays on stable v68.

## After testing

In GitHub Actions, run **Android Release → Run workflow** and enter:

```text
v69-test
```

The workflow changes that existing release from prerelease to the latest stable release. No second APK build is needed.

After promotion:

- Admin → v69
- Shops → v69
- Storekeepers → v69

The APK is signed with the same release key, so Android can install it over the existing app.
