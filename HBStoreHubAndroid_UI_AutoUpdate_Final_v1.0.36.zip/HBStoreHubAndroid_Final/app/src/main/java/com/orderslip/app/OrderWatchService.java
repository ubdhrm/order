package com.orderslip.app;

import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import androidx.core.app.NotificationCompat;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Foreground service that checks Firestore every ~45 seconds (REST, light queries) so that
 * order notifications arrive on time even when the app is closed.
 *  - shop:        tells the shop when its order becomes NOTED or COMPLETED
 *  - storekeeper: tells the storekeeper about NEW orders and items added to an existing order
 */
public class OrderWatchService extends Service {
    static final String PREFS = "hb_watch";
    private static final String API_KEY = "AIzaSyCkYisLrdqcKsiCINNbEuvrBomY41Rl8kI";
    private static final String DOCS = "https://firestore.googleapis.com/v1/projects/hb-order-slip/databases/(default)/documents";
    private static final long POLL_MS = 45000L;
    private static final int FG_ID = 4711;

    private volatile boolean running = false;
    private Thread worker;
    private PowerManager.WakeLock wakeLock;
    private String idToken;
    private long idTokenExpiry;

    static void start(Context c) {
        try {
            Intent i = new Intent(c, OrderWatchService.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
        } catch (Exception ignored) {}
    }

    static void stop(Context c) {
        try { c.stopService(new Intent(c, OrderWatchService.class)); } catch (Exception ignored) {}
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        OrderNotifier.ensureChannels(this);
        Notification n = new NotificationCompat.Builder(this, OrderNotifier.CHANNEL_WATCH)
                .setSmallIcon(R.drawable.ic_stat_notify)
                .setContentTitle(" ")
                .setContentText(" ")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setSilent(true)
                .setShowWhen(false)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .setContentIntent(OrderNotifier.openAppIntent(this))
                .build();
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(FG_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else startForeground(FG_ID, n);
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (sp.getString("refreshToken", "").isEmpty() || sp.getString("role", "").isEmpty()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!running) {
            running = true;
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "hbstore:orderwatch");
                wakeLock.setReferenceCounted(false);
            }
            worker = new Thread(this::loop, "hb-order-watch");
            worker.start();
        }
        return START_STICKY;
    }

    @Override public void onDestroy() {
        running = false;
        if (worker != null) worker.interrupt();
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Exception ignored) {}
        super.onDestroy();
    }

    // ------------------------------------------------------------------ loop

    private void loop() {
        long backoff = 0;
        while (running) {
            try {
                if (wakeLock != null) wakeLock.acquire(120000L);   // renewed every round, never held forever
                SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
                String role = sp.getString("role", "");
                if ("storekeeper".equals(role)) pollStorekeeper(sp);
                else if ("shop".equals(role)) pollShop(sp);
                else { running = false; stopSelf(); return; }
                backoff = 0;
            } catch (Exception e) {
                String m = String.valueOf(e.getMessage());
                if (m.contains("HTTP 401") || m.contains("HTTP 403")) idToken = null;
                backoff = backoff == 0 ? 60000L : Math.min(backoff * 2, 300000L);
            }
            try { Thread.sleep(POLL_MS + backoff); } catch (InterruptedException e) { return; }
        }
    }

    // ------------------------------------------------------------------ shop

    /** Watches this shop's open orders (pending / noted). */
    private void pollShop(SharedPreferences sp) throws Exception {
        String uid = sp.getString("uid", "");
        String token = getIdToken(sp);

        JSONObject sq = new JSONObject();
        sq.put("from", new JSONArray().put(new JSONObject().put("collectionId", "orders")));
        sq.put("select", projection("status", "orderNo"));
        JSONArray vals = new JSONArray()
                .put(new JSONObject().put("stringValue", "pending"))
                .put(new JSONObject().put("stringValue", "accepted"));
        JSONArray filters = new JSONArray()
                .put(fieldFilter("shopUid", "EQUAL", new JSONObject().put("stringValue", uid)))
                .put(fieldFilter("status", "IN", new JSONObject().put("arrayValue", new JSONObject().put("values", vals))));
        sq.put("where", new JSONObject().put("compositeFilter", new JSONObject().put("op", "AND").put("filters", filters)));
        JSONArray res = runQuery(token, sq);

        Map<String, String[]> cur = new HashMap<>();   // id -> {status, orderNo}
        for (int i = 0; i < res.length(); i++) {
            JSONObject doc = res.getJSONObject(i).optJSONObject("document");
            if (doc == null) continue;
            JSONObject f = doc.optJSONObject("fields");
            String status = str(f, "status");
            String orderNo = str(f, "orderNo");
            cur.put(idOf(doc.optString("name")), new String[]{status, orderNo});
        }

        String prevJson = sp.getString("shopMap", null);
        JSONObject prev = prevJson == null ? null : new JSONObject(prevJson);
        JSONObject next = new JSONObject();
        for (Map.Entry<String, String[]> e : cur.entrySet()) {
            next.put(e.getKey(), new JSONObject().put("s", e.getValue()[0]).put("n", e.getValue()[1]));
        }

        if (prev != null) {
            // pending -> noted
            for (Map.Entry<String, String[]> e : cur.entrySet()) {
                JSONObject p = prev.optJSONObject(e.getKey());
                if (p != null && "pending".equals(p.optString("s")) && "accepted".equals(e.getValue()[0])) {
                    OrderNotifier.showUnlessForeground(this, "Order noted",
                            label(e.getValue()[1]) + " has been noted by the storekeeper");
                }
            }
            // no longer open -> completed?
            Iterator<String> it = prev.keys();
            while (it.hasNext()) {
                String id = it.next();
                if (cur.containsKey(id)) continue;
                JSONObject p = prev.optJSONObject(id);
                try {
                    String doc = http("GET", DOCS + "/orders/" + id + "?mask.fieldPaths=status&mask.fieldPaths=orderNo",
                            null, null, token);
                    JSONObject f = new JSONObject(doc).optJSONObject("fields");
                    if ("completed".equals(str(f, "status"))) {
                        String no = str(f, "orderNo");
                        if (no.isEmpty() && p != null) no = p.optString("n");
                        OrderNotifier.showUnlessForeground(this, "Order completed \u2713", label(no) + " has been completed");
                    }
                } catch (Exception ex) {
                    String m = String.valueOf(ex.getMessage());
                    if (!m.contains("HTTP 404")) next.put(id, p);   // try again next round
                }
            }
        }
        sp.edit().putString("shopMap", next.toString()).apply();
    }

    private static String label(String orderNo) {
        return (orderNo == null || orderNo.isEmpty()) ? "Your order" : ("Order #" + orderNo);
    }

    // ------------------------------------------------------------------ storekeeper

    /** Watches every order changed since the last check (needs no extra Firestore index). */
    private void pollStorekeeper(SharedPreferences sp) throws Exception {
        String token = getIdToken(sp);
        String last = sp.getString("skLast", null);
        if (last == null) last = isoNow(-60000L);
        long lastKey = tsKey(last);

        JSONObject sq = new JSONObject();
        sq.put("from", new JSONArray().put(new JSONObject().put("collectionId", "orders")));
        sq.put("select", projection("status", "orderNo", "shopName", "createdAt", "updatedAt", "addedAt"));
        sq.put("where", fieldFilter("updatedAt", "GREATER_THAN", new JSONObject().put("timestampValue", last)));
        JSONArray res = runQuery(token, sq);

        Set<String> seen = new LinkedHashSet<>();
        JSONArray seenArr = new JSONArray(sp.getString("skSeen", "[]"));
        for (int i = 0; i < seenArr.length(); i++) seen.add(seenArr.getString(i));

        String maxTs = last;
        long maxKey = lastKey;
        List<String> newOrders = new ArrayList<>();
        List<String> updated = new ArrayList<>();

        for (int i = 0; i < res.length(); i++) {
            JSONObject doc = res.getJSONObject(i).optJSONObject("document");
            if (doc == null) continue;
            JSONObject f = doc.optJSONObject("fields");
            String id = idOf(doc.optString("name"));
            String status = str(f, "status");
            String no = str(f, "orderNo");
            String shop = str(f, "shopName");
            String createdAt = ts(f, "createdAt");
            String updatedAt = ts(f, "updatedAt");
            String addedAt = ts(f, "addedAt");
            long uk = tsKey(updatedAt);
            if (uk > maxKey) { maxKey = uk; maxTs = updatedAt; }
            String who = shop.isEmpty() ? "A shop" : shop;
            if ("pending".equals(status) && !seen.contains(id) && tsKey(createdAt) > lastKey) {
                seen.add(id);
                newOrders.add(who + " sent " + (no.isEmpty() ? "a new order" : "Order #" + no));
            } else if (!addedAt.isEmpty() && tsKey(addedAt) > lastKey && !"completed".equals(status)) {
                updated.add(who + " added items to " + (no.isEmpty() ? "an order" : "Order #" + no));
            }
        }

        if (newOrders.size() == 1) OrderNotifier.showUnlessForeground(this, "New order", newOrders.get(0));
        else if (newOrders.size() > 1) OrderNotifier.showUnlessForeground(this, "New orders", newOrders.size() + " new orders received");
        if (updated.size() == 1) OrderNotifier.showUnlessForeground(this, "Order updated", updated.get(0));
        else if (updated.size() > 1) OrderNotifier.showUnlessForeground(this, "Orders updated", "Shops added items to " + updated.size() + " orders");

        // keep the "seen" list short
        JSONArray out = new JSONArray();
        int skip = Math.max(0, seen.size() - 300), idx = 0;
        for (String s : seen) { if (idx++ >= skip) out.put(s); }
        sp.edit().putString("skLast", maxTs).putString("skSeen", out.toString()).apply();
    }

    // ------------------------------------------------------------------ Firestore REST helpers

    private JSONArray runQuery(String token, JSONObject structuredQuery) throws Exception {
        String body = new JSONObject().put("structuredQuery", structuredQuery).toString();
        return new JSONArray(http("POST", DOCS + ":runQuery", body, "application/json", token));
    }

    private static JSONObject projection(String... names) throws Exception {
        JSONArray a = new JSONArray();
        for (String n : names) a.put(new JSONObject().put("fieldPath", n));
        return new JSONObject().put("fields", a);
    }

    private static JSONObject fieldFilter(String field, String op, JSONObject value) throws Exception {
        return new JSONObject().put("fieldFilter", new JSONObject()
                .put("field", new JSONObject().put("fieldPath", field))
                .put("op", op)
                .put("value", value));
    }

    private static String idOf(String docName) {
        int i = docName.lastIndexOf('/');
        return i >= 0 ? docName.substring(i + 1) : docName;
    }

    private static String str(JSONObject fields, String name) {
        if (fields == null) return "";
        JSONObject v = fields.optJSONObject(name);
        return v == null ? "" : v.optString("stringValue", "");
    }

    private static String ts(JSONObject fields, String name) {
        if (fields == null) return "";
        JSONObject v = fields.optJSONObject(name);
        return v == null ? "" : v.optString("timestampValue", "");
    }

    /** Turns "2026-09-20T12:34:56.789012Z" into a sortable number (0 if empty/unreadable). */
    private static long tsKey(String t) {
        try {
            if (t == null || t.isEmpty()) return 0L;
            if (t.endsWith("Z")) t = t.substring(0, t.length() - 1);
            String main = t, frac = "";
            int dot = t.indexOf('.');
            if (dot >= 0) { main = t.substring(0, dot); frac = t.substring(dot + 1); }
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
            f.setTimeZone(TimeZone.getTimeZone("UTC"));
            long secs = f.parse(main).getTime() / 1000L;
            StringBuilder sb = new StringBuilder(frac);
            while (sb.length() < 9) sb.append('0');
            long nanos = Long.parseLong(sb.substring(0, 9));
            return secs * 1000000000L + nanos;
        } catch (Exception e) {
            return 0L;
        }
    }

    private static String isoNow(long offsetMs) {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new java.util.Date(System.currentTimeMillis() + offsetMs));
    }

    private String getIdToken(SharedPreferences sp) throws Exception {
        if (idToken != null && System.currentTimeMillis() < idTokenExpiry - 60000L) return idToken;
        String body = "grant_type=refresh_token&refresh_token=" + URLEncoder.encode(sp.getString("refreshToken", ""), "UTF-8");
        String res = http("POST", "https://securetoken.googleapis.com/v1/token?key=" + API_KEY,
                body, "application/x-www-form-urlencoded", null);
        JSONObject j = new JSONObject(res);
        idToken = j.getString("id_token");
        long expiresIn = Long.parseLong(j.optString("expires_in", "3600"));
        idTokenExpiry = System.currentTimeMillis() + expiresIn * 1000L;
        String newRefresh = j.optString("refresh_token", "");
        if (!newRefresh.isEmpty()) sp.edit().putString("refreshToken", newRefresh).apply();
        return idToken;
    }

    private String http(String method, String url, String body, String contentType, String bearer) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setRequestMethod(method);
            c.setConnectTimeout(15000);
            c.setReadTimeout(20000);
            if (bearer != null) c.setRequestProperty("Authorization", "Bearer " + bearer);
            if (body != null) {
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", contentType);
                OutputStream os = c.getOutputStream();
                os.write(body.getBytes("UTF-8"));
                os.close();
            }
            int code = c.getResponseCode();
            InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String text = readAll(is);
            if (code >= 400) throw new IOException("HTTP " + code + " " + text);
            return text;
        } finally {
            c.disconnect();
        }
    }

    private static String readAll(InputStream is) throws IOException {
        if (is == null) return "";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = is.read(buf)) != -1) out.write(buf, 0, n);
        is.close();
        return out.toString("UTF-8");
    }
}
