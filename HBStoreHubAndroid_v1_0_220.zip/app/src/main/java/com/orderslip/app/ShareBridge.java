package com.orderslip.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfDocument;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import org.json.JSONArray;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import java.util.concurrent.TimeUnit;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/** Native helpers the HTML calls as window.AndroidShare.* (WebView has no Web Share / file download). */
public class ShareBridge {
    private final Activity activity;
    private WebView pendingPdfWebView; // kept alive while the off-screen render + PDF write is in flight

    ShareBridge(Activity activity) { this.activity = activity; }

    private static String cleanName(String name, String fallback) {
        String n = name == null ? "" : name.replaceAll("[\\\\/:*?\"<>|\\r\\n]+", "").trim();
        return n.isEmpty() ? fallback : n;
    }

    private void toast(final String msg) {
        activity.runOnUiThread(() -> Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show());
    }

    private File writeToCache(String folder, String name, byte[] bytes) throws Exception {
        File dir = new File(activity.getCacheDir(), folder);
        if (!dir.exists()) dir.mkdirs();
        File[] old = dir.listFiles();
        if (old != null) for (File f : old) f.delete();   // keep cache small
        File out = new File(dir, name);
        FileOutputStream fos = new FileOutputStream(out);
        try { fos.write(bytes); } finally { fos.close(); }
        return out;
    }

    private void openShareSheet(final Uri uri, final String mime, final String text) {
        activity.runOnUiThread(() -> {
            try {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType(mime);
                send.putExtra(Intent.EXTRA_STREAM, uri);
                if (text != null && text.length() > 0) send.putExtra(Intent.EXTRA_TEXT, text);
                send.setClipData(ClipData.newRawUri("", uri));
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Intent chooser = Intent.createChooser(send, "Share order");
                chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                activity.startActivity(chooser);
            } catch (Exception e) {
                Toast.makeText(activity, "Could not open share", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /** Send the order file through the Android share sheet (WhatsApp etc). */
    @JavascriptInterface
    public void shareHtml(String filename, String html, String text) {
        try {
            String name = cleanName(filename, "Order.html");
            File f = writeToCache("shared", name, html.getBytes("UTF-8"));
            Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", f);
            openShareSheet(uri, "text/html", text);
        } catch (Exception e) {
            toast("Could not share order");
        }
    }

    /** Share plain text straight to WhatsApp (falls back to the share sheet). */
    @JavascriptInterface
    public void shareText(final String text) {
        activity.runOnUiThread(() -> {
            String[] pkgs = {"com.whatsapp", "com.whatsapp.w4b"};
            for (String pkg : pkgs) {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                    send.setPackage(pkg);
                    activity.startActivity(send);
                    return;
                } catch (Exception ignored) { }
            }
            try {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                activity.startActivity(Intent.createChooser(send, "Share order"));
            } catch (Exception e) {
                Toast.makeText(activity, "Could not open share", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /** Render an HTML order summary to a real PDF (off-screen WebView snapshotted onto
     *  PdfDocument pages -- no print dialog) and hand it straight to WhatsApp.
     *  v1.0.165: fixes the blank PDF. The old code laid the WebView out to full height and drew it
     *  at once, before Chromium had re-rendered at the new size, so the snapshot was white. Now we
     *  wait for a rendered frame (postVisualStateCallback), resize, wait again, then draw page by
     *  page. If the result is still blank we fall back to sharing plain text. */
    @JavascriptInterface
    public void sharePdf(final String filename, final String html, final String text) {
        activity.runOnUiThread(() -> {
            try {
                final int widthPx = 1000;
                final float density = activity.getResources().getDisplayMetrics().density;
                final WebView pdfWeb = new WebView(activity);
                pendingPdfWebView = pdfWeb;
                pdfWeb.getSettings().setUseWideViewPort(false);
                pdfWeb.getSettings().setLoadWithOverviewMode(false);
                pdfWeb.setInitialScale((int) (density * 100));
                pdfWeb.setVerticalScrollBarEnabled(false);
                pdfWeb.setHorizontalScrollBarEnabled(false);
                pdfWeb.setBackgroundColor(Color.WHITE);

                ViewGroup root = (ViewGroup) activity.getWindow().getDecorView();
                final android.widget.FrameLayout.LayoutParams lp =
                        new android.widget.FrameLayout.LayoutParams(widthPx, 1500);
                pdfWeb.setLayoutParams(lp);
                pdfWeb.setTranslationX(-20000f);
                root.addView(pdfWeb);

                pdfWeb.setWebViewClient(new WebViewClient() {
                    private boolean started = false;
                    @Override
                    public void onPageFinished(final WebView view, String url) {
                        if (started) return;
                        started = true;
                        // 1) wait until the first frame is really rendered
                        view.postVisualStateCallback(1L, new WebView.VisualStateCallback() {
                            @Override public void onComplete(long requestId) {
                                int h = (int) Math.ceil(view.getContentHeight() * density);
                                if (h < 400) h = 400;
                                if (h > 30000) h = 30000;
                                final int contentH = h;
                                lp.height = contentH;
                                view.setLayoutParams(lp);
                                view.requestLayout();
                                // 2) wait again so Chromium re-renders at the full height
                                view.postDelayed(() -> view.postVisualStateCallback(2L,
                                        new WebView.VisualStateCallback() {
                                            @Override public void onComplete(long id2) {
                                                view.postDelayed(() ->
                                                        renderWebViewToPdf(view, widthPx, contentH, filename, text), 250);
                                            }
                                        }), 250);
                            }
                        });
                    }
                });
                pdfWeb.loadDataWithBaseURL(null, html == null ? "" : html, "text/html", "UTF-8", null);
            } catch (Exception e) {
                toast("Could not create PDF");
                shareText(text);
            }
        });
    }

    private static boolean isBlank(Bitmap b) {
        try {
            Bitmap small = Bitmap.createScaledBitmap(b, 60, 84, false);
            int[] px = new int[60 * 84];
            small.getPixels(px, 0, 60, 0, 0, 60, 84);
            small.recycle();
            for (int c : px) if ((c & 0x00FFFFFF) != 0x00FFFFFF) return false;
            return true;
        } catch (Throwable t) { return false; }
    }

    private void renderWebViewToPdf(final WebView view, final int widthPx, final int contentHeightPx,
                                    final String filename, final String text) {
        PdfDocument doc = null;
        try {
            final int pageH = (int) (widthPx * 1.4142f); // A4 proportion
            int pages = (int) Math.ceil(contentHeightPx / (float) pageH);
            if (pages < 1) pages = 1;

            view.measure(
                    View.MeasureSpec.makeMeasureSpec(widthPx, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(contentHeightPx, View.MeasureSpec.EXACTLY));
            view.layout(0, 0, widthPx, contentHeightPx);

            doc = new PdfDocument();
            boolean anyContent = false;
            for (int i = 0; i < pages; i++) {
                Bitmap bmp = Bitmap.createBitmap(widthPx, pageH, Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(bmp);
                c.drawColor(Color.WHITE);
                c.translate(0f, -(float) (i * pageH));
                view.draw(c);
                if (!isBlank(bmp)) anyContent = true;
                PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(widthPx, pageH, i + 1).create();
                PdfDocument.Page page = doc.startPage(info);
                page.getCanvas().drawBitmap(bmp, 0f, 0f, null);
                doc.finishPage(page);
                bmp.recycle();
            }

            if (!anyContent) {   // still blank -> never send an empty PDF
                cleanupPdfWebView(view);
                toast("PDF blank aayi - text ayi share cheyyunnu");
                shareText(text);
                return;
            }

            String name = cleanName(filename, "Order.pdf");
            File dir = new File(activity.getCacheDir(), "shared");
            if (!dir.exists()) dir.mkdirs();
            File[] old = dir.listFiles();
            if (old != null) for (File f : old) f.delete();
            File out = new File(dir, name);
            FileOutputStream fos = new FileOutputStream(out);
            try { doc.writeTo(fos); } finally { fos.close(); }

            cleanupPdfWebView(view);
            Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", out);
            shareFileToWhatsapp(uri, "application/pdf", text);
        } catch (Throwable e) {
            cleanupPdfWebView(view);
            toast("Could not create PDF");
            shareText(text);
        } finally {
            if (doc != null) doc.close();
        }
    }

    private void cleanupPdfWebView(final WebView view) {
        activity.runOnUiThread(() -> {
            try {
                ViewGroup parent = (ViewGroup) view.getParent();
                if (parent != null) parent.removeView(view);
                view.destroy();
            } catch (Exception ignored) {}
            if (pendingPdfWebView == view) pendingPdfWebView = null;
        });
    }

    /** Send a file (e.g. the generated PDF) straight to WhatsApp, falling back to the share sheet. */
    private void shareFileToWhatsapp(final Uri uri, final String mime, final String text) {
        activity.runOnUiThread(() -> {
            String[] pkgs = {"com.whatsapp", "com.whatsapp.w4b"};
            for (String pkg : pkgs) {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType(mime);
                    send.putExtra(Intent.EXTRA_STREAM, uri);
                    if (text != null && text.length() > 0) send.putExtra(Intent.EXTRA_TEXT, text);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    send.setPackage(pkg);
                    activity.startActivity(send);
                    return;
                } catch (Exception ignored) { }
            }
            openShareSheet(uri, mime, text);
        });
    }

    /** Save a photo (data URL) to Pictures/OrderSlip. */
    @JavascriptInterface
    public void savePhoto(String filename, String dataUrl) {
        try {
            String name = cleanName(filename, "photo.jpg");
            byte[] bytes = Base64.decode(dataUrl.substring(dataUrl.indexOf(',') + 1), Base64.DEFAULT);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/OrderSlip");
                Uri uri = activity.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new Exception("insert failed");
                OutputStream os = activity.getContentResolver().openOutputStream(uri);
                try { os.write(bytes); } finally { os.close(); }
            } else {
                File f = writeToCache("shared", name, bytes);
                Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", f);
                openShareSheet(uri, "image/jpeg", null);
            }
        } catch (Exception e) {
            toast("Could not save photo");
        }
    }

    /** Save an arbitrary file (data URL) to Downloads/OrderSlip. Used for non-photo
     *  attachments such as the completion PDF, since savePhoto() above always writes
     *  image/jpeg and would corrupt anything else. */
    @JavascriptInterface
    public void saveFile(String filename, String dataUrl, String mimeType) {
        try {
            String mime = (mimeType == null || mimeType.isEmpty()) ? "application/octet-stream" : mimeType;
            String name = cleanName(filename, "file");
            byte[] bytes = Base64.decode(dataUrl.substring(dataUrl.indexOf(',') + 1), Base64.DEFAULT);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/OrderSlip");
                Uri uri = activity.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new Exception("insert failed");
                OutputStream os = activity.getContentResolver().openOutputStream(uri);
                try { os.write(bytes); } finally { os.close(); }
                toast("Saved to Downloads/OrderSlip");
            } else {
                File f = writeToCache("shared", name, bytes);
                Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", f);
                openShareSheet(uri, mime, null);
            }
        } catch (Exception e) {
            toast("Could not save file");
        }
    }

    /** Show a system notification right now (kept for the HTML; the background service uses OrderNotifier directly). */
    @JavascriptInterface
    public void showNotification(String title, String body) {
        OrderNotifier.show(activity, title, body);
    }

    /** "Check for update" button in the Saved tab. */
    @JavascriptInterface
    public void checkUpdate() {
        if (activity instanceof MainActivity) {
            final MainActivity a = (MainActivity) activity;
            activity.runOnUiThread(() -> a.checkForUpdate(true));
        }
    }

    /** Installed app version (shown in the Saved tab so it is easy to see which build is running). */
    @JavascriptInterface
    public String getVersion() { return BuildConfig.VERSION_NAME; }

    /** Starts background sync without a persistent/running notification.
     * WorkManager performs an immediate one-time sync and then periodic sync while the app is closed.
     * Android may delay periodic work; the in-app Firestore listener remains real-time while open.
     */
    @JavascriptInterface
    public void startWatcher(String role, String uid, String refreshToken) {
        try {
            if (role == null || uid == null || refreshToken == null || refreshToken.isEmpty()) return;
            SharedPreferences sp = activity.getSharedPreferences(OrderSyncWorker.PREFS, Context.MODE_PRIVATE);
            boolean sameUser = uid.equals(sp.getString("uid", "")) && role.equals(sp.getString("role", ""));
            SharedPreferences.Editor ed = sp.edit()
                    .putString("role", role).putString("uid", uid).putString("refreshToken", refreshToken);
            if (!sameUser) ed.remove("shopMap").remove("skLast").remove("skSeen");
            ed.apply();

            Constraints constraints = new Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build();
            WorkManager wm = WorkManager.getInstance(activity.getApplicationContext());

            OneTimeWorkRequest now = new OneTimeWorkRequest.Builder(OrderSyncWorker.class)
                    .setConstraints(constraints).build();
            wm.enqueueUniqueWork("hb_order_sync_now", ExistingWorkPolicy.REPLACE, now);

            PeriodicWorkRequest periodic = new PeriodicWorkRequest.Builder(OrderSyncWorker.class, 15, TimeUnit.MINUTES)
                    .setConstraints(constraints).build();
            wm.enqueueUniquePeriodicWork("hb_order_sync", ExistingPeriodicWorkPolicy.UPDATE, periodic);
        } catch (Exception ignored) {}
    }

    /** Stops background sync on logout. */
    @JavascriptInterface
    public void stopWatcher() {
        try {
            activity.getSharedPreferences(OrderSyncWorker.PREFS, Context.MODE_PRIVATE).edit()
                    .remove("role").remove("uid").remove("refreshToken")
                    .remove("shopMap").remove("skLast").remove("skSeen").remove(OrderWidgetProvider.KEY).apply();
            OrderWidgetProvider.refreshAll(activity.getApplicationContext());
            WorkManager wm = WorkManager.getInstance(activity.getApplicationContext());
            wm.cancelUniqueWork("hb_order_sync_now");
            wm.cancelUniqueWork("hb_order_sync");
        } catch (Exception ignored) {}
    }

    /** Storekeeper home-screen widget: saves the open-order list (JSON) and redraws the widget. */
    @JavascriptInterface
    public void updateWidget(String json) {
        try {
            if (json == null) return;
            new JSONArray(json); // validate
            activity.getSharedPreferences(OrderSyncWorker.PREFS, Context.MODE_PRIVATE).edit()
                    .putString(OrderWidgetProvider.KEY, json).apply();
            OrderWidgetProvider.refreshAll(activity.getApplicationContext());
        } catch (Exception ignored) {}
    }

    /** Sends the app to the background so the phone's home screen shows (app stays warm for quick reopen). */
    @JavascriptInterface
    public void goHome() {
        activity.runOnUiThread(() -> activity.moveTaskToBack(true));
    }
}
