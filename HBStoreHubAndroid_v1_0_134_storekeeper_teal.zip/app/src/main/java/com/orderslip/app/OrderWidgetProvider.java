package com.orderslip.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.widget.RemoteViews;
import org.json.JSONArray;

/** Home-screen widget for the storekeeper: shows open shop orders (new ones first). */
public class OrderWidgetProvider extends AppWidgetProvider {
    /** Prefs key (inside OrderSyncWorker.PREFS) holding a JSON array of open orders. */
    static final String KEY = "widgetOrders";

    @Override public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) update(ctx, mgr, id);
    }

    /** Re-draws every placed widget from the saved order list. Safe to call from any thread. */
    static void refreshAll(Context ctx) {
        try {
            Context app = ctx.getApplicationContext();
            AppWidgetManager mgr = AppWidgetManager.getInstance(app);
            int[] ids = mgr.getAppWidgetIds(new ComponentName(app, OrderWidgetProvider.class));
            if (ids == null || ids.length == 0) return;
            for (int id : ids) update(app, mgr, id);
            mgr.notifyAppWidgetViewDataChanged(ids, R.id.widget_list);
        } catch (Exception ignored) {}
    }

    static boolean hasWidgets(Context ctx) {
        try {
            Context app = ctx.getApplicationContext();
            int[] ids = AppWidgetManager.getInstance(app).getAppWidgetIds(new ComponentName(app, OrderWidgetProvider.class));
            return ids != null && ids.length > 0;
        } catch (Exception e) { return false; }
    }

    private static void update(Context ctx, AppWidgetManager mgr, int id) {
        RemoteViews rv = new RemoteViews(ctx.getPackageName(), R.layout.widget_orders);
        int fresh = 0, total = 0;
        boolean signedIn = "storekeeper".equals(prefs(ctx).getString("role", ""));
        try {
            JSONArray a = new JSONArray(prefs(ctx).getString(KEY, "[]"));
            total = a.length();
            for (int i = 0; i < a.length(); i++) if ("pending".equals(a.getJSONObject(i).optString("st"))) fresh++;
        } catch (Exception ignored) {}

        rv.setTextViewText(R.id.widget_title, "HB Store Hub");
        String sub;
        if (!signedIn) sub = "Open the app and log in";
        else if (total == 0) sub = "No open orders";
        else if (fresh > 0) sub = fresh + (fresh == 1 ? " new order" : " new orders") + " · " + total + " open";
        else sub = total + (total == 1 ? " order open" : " orders open");
        rv.setTextViewText(R.id.widget_subtitle, sub);
        rv.setTextViewText(R.id.widget_empty, signedIn ? "No open orders ✓" : "Storekeeper login needed");

        Intent svc = new Intent(ctx, OrderWidgetService.class);
        svc.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
        svc.setData(Uri.parse(svc.toUri(Intent.URI_INTENT_SCHEME)));
        rv.setRemoteAdapter(R.id.widget_list, svc);
        rv.setEmptyView(R.id.widget_list, R.id.widget_empty);

        // Tapping the header or empty text opens the app; tapping a row (template) opens it too.
        PendingIntent open = PendingIntent.getActivity(ctx, 0,
                new Intent(ctx, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.widget_header, open);
        rv.setOnClickPendingIntent(R.id.widget_empty, open);
        int mutable = Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0;
        PendingIntent template = PendingIntent.getActivity(ctx, 1,
                new Intent(ctx, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT | mutable);
        rv.setPendingIntentTemplate(R.id.widget_list, template);
        mgr.updateAppWidget(id, rv);
    }

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences(OrderSyncWorker.PREFS, Context.MODE_PRIVATE);
    }
}
