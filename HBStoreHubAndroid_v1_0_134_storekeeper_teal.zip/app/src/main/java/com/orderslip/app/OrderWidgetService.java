package com.orderslip.app;

import android.content.Context;
import android.content.Intent;
import android.text.format.DateUtils;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/** Feeds the order rows of the storekeeper widget's list. */
public class OrderWidgetService extends RemoteViewsService {
    @Override public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new Factory(getApplicationContext());
    }

    private static final class Row { String shop, no, st; long t; }

    private static final class Factory implements RemoteViewsFactory {
        private final Context ctx;
        private final List<Row> rows = new ArrayList<>();

        Factory(Context c) { ctx = c; }

        @Override public void onCreate() {}
        @Override public void onDestroy() { rows.clear(); }

        @Override public void onDataSetChanged() {
            rows.clear();
            try {
                String role = ctx.getSharedPreferences(OrderSyncWorker.PREFS, Context.MODE_PRIVATE).getString("role", "");
                if (!"storekeeper".equals(role)) return;
                JSONArray a = new JSONArray(ctx.getSharedPreferences(OrderSyncWorker.PREFS, Context.MODE_PRIVATE)
                        .getString(OrderWidgetProvider.KEY, "[]"));
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    Row r = new Row();
                    r.shop = o.optString("s", "Shop");
                    r.no = o.optString("n", "");
                    r.st = o.optString("st", "");
                    r.t = o.optLong("t", 0L);
                    rows.add(r);
                }
                // New (pending) orders first, then newest first.
                Collections.sort(rows, new Comparator<Row>() {
                    @Override public int compare(Row x, Row y) {
                        int px = "pending".equals(x.st) ? 0 : 1, py = "pending".equals(y.st) ? 0 : 1;
                        if (px != py) return px - py;
                        return Long.compare(y.t, x.t);
                    }
                });
            } catch (Exception ignored) {}
        }

        @Override public int getCount() { return rows.size(); }

        @Override public RemoteViews getViewAt(int pos) {
            RemoteViews rv = new RemoteViews(ctx.getPackageName(), R.layout.widget_row);
            if (pos < 0 || pos >= rows.size()) return rv;
            Row r = rows.get(pos);
            boolean fresh = "pending".equals(r.st);
            rv.setTextViewText(R.id.row_shop, r.shop.isEmpty() ? "Shop" : r.shop);
            String when = r.t > 0
                    ? DateUtils.getRelativeTimeSpanString(r.t, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS,
                            DateUtils.FORMAT_ABBREV_RELATIVE).toString()
                    : "";
            String sub = (r.no.isEmpty() ? "Order" : "Order #" + r.no) + (when.isEmpty() ? "" : " · " + when);
            rv.setTextViewText(R.id.row_sub, sub);
            boolean packing = "packing".equals(r.st);
            rv.setTextViewText(R.id.row_status, fresh ? "NEW" : (packing ? "PACKING" : "CHECKED"));
            rv.setInt(R.id.row_status, "setBackgroundResource",
                    fresh ? R.drawable.widget_pill_new : (packing ? R.drawable.widget_pill_packing : R.drawable.widget_pill_open));
            rv.setOnClickFillInIntent(R.id.row_shop, new Intent());
            rv.setOnClickFillInIntent(R.id.row_sub, new Intent());
            rv.setOnClickFillInIntent(R.id.row_status, new Intent());
            return rv;
        }

        @Override public RemoteViews getLoadingView() { return null; }
        @Override public int getViewTypeCount() { return 1; }
        @Override public long getItemId(int pos) { return pos; }
        @Override public boolean hasStableIds() { return false; }
    }
}
