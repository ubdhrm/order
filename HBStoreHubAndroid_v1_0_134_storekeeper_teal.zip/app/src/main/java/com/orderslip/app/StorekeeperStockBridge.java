package com.orderslip.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.xml.parsers.DocumentBuilderFactory;

/** Local Storekeeper-only Excel importer. No cloud upload is used. */
public class StorekeeperStockBridge {
    private static final int PICK_STOCK_EXCEL = 2201;
    private final Activity activity;
    private final WebView webView;

    public StorekeeperStockBridge(Activity activity, WebView webView) {
        this.activity = activity;
        this.webView = webView;
    }

    @JavascriptInterface
    public void setStatusBar(final String hex) {
        activity.runOnUiThread(() -> {
            try {
                activity.getWindow().setStatusBarColor(android.graphics.Color.parseColor(hex));
            } catch (Exception ignored) { }
        });
    }

    @JavascriptInterface
    public void openStockExcel() {
        activity.runOnUiThread(() -> {
            try {
                Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
                activity.startActivityForResult(pick, PICK_STOCK_EXCEL);
            } catch (Exception e) {
                try {
                    Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                    pick.addCategory(Intent.CATEGORY_OPENABLE);
                    pick.setType("*/*");
                    pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
                    activity.startActivityForResult(pick, PICK_STOCK_EXCEL);
                } catch (Exception ignored) {
                    Toast.makeText(activity, "Could not open Excel picker", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public boolean handleResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != PICK_STOCK_EXCEL) return false;
        if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null) return true;
        Uri uri = data.getData();
        activity.runOnUiThread(() -> Toast.makeText(activity, "Reading stock Excel…", Toast.LENGTH_SHORT).show());
        new Thread(() -> {
            try {
                String json = parseXlsx(uri);
                webView.post(() -> webView.evaluateJavascript(
                        "window.onNativeStockExcelReady(" + JSONObject.quote(json) + ");", null));
            } catch (Exception e) {
                String msg = e.getMessage() == null ? "Invalid Excel file" : e.getMessage();
                activity.runOnUiThread(() -> Toast.makeText(activity, "Stock Excel error: " + msg, Toast.LENGTH_LONG).show());
            }
        }).start();
        return true;
    }

    private String parseXlsx(Uri uri) throws Exception {
        java.io.File temp = java.io.File.createTempFile("stock_", ".xlsx", activity.getCacheDir());
        try (InputStream in = activity.getContentResolver().openInputStream(uri);
             java.io.FileOutputStream out = new java.io.FileOutputStream(temp)) {
            if (in == null) throw new Exception("Cannot read selected file");
            byte[] buf = new byte[32768]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }

        try (ZipFile zip = new ZipFile(temp)) {
            List<String> shared = readSharedStrings(zip);
            String sheetPath = firstSheetPath(zip);
            ZipEntry sheet = zip.getEntry(sheetPath);
            if (sheet == null) throw new Exception("First worksheet not found");
            Document doc = xml(zip.getInputStream(sheet));
            NodeList rows = doc.getElementsByTagName("row");
            if (rows.getLength() == 0) throw new Exception("Excel has no rows");

            List<Map<Integer,String>> data = new ArrayList<>();
            for (int r = 0; r < rows.getLength(); r++) {
                Element row = (Element) rows.item(r);
                Map<Integer,String> vals = new HashMap<>();
                NodeList cells = row.getElementsByTagName("c");
                for (int i = 0; i < cells.getLength(); i++) {
                    Element c = (Element) cells.item(i);
                    String ref = c.getAttribute("r");
                    int col = colIndex(ref);
                    vals.put(col, cellValue(c, shared));
                }
                data.add(vals);
            }

            int headerRow = -1, codeCol = -1, nameCol = -1, qtyCol = -1, unitCol = -1;
            for (int r = 0; r < Math.min(data.size(), 15); r++) {
                Map<Integer,String> row = data.get(r);
                int rCode = -1, rName = -1, rQty = -1, rUnit = -1;
                int qtyScore = 0, codeScore = 0, unitScore = 0;
                java.util.List<Integer> cols = new ArrayList<>(row.keySet());
                java.util.Collections.sort(cols);
                for (int colKey : cols) {
                    String h = norm(row.get(colKey));
                    if (h.isEmpty()) continue;
                    // Code column: prefer "Item Code"/"Item No" over Barcode/SKU.
                    int cs = 0;
                    if (h.equals("item code") || h.equals("item no") || h.equals("item number") || h.equals("item#")) cs = 3;
                    else if (containsAny(h, "item code", "item no", "item number", "item#")) cs = 2;
                    else if (!h.contains("barcode") && containsAny(h, "code", "sku")) cs = 1;
                    boolean isCodeHeader = cs > 0 || h.contains("barcode");
                    if (cs > codeScore) { codeScore = cs; rCode = colKey; }
                    // "Item No" also contains the word "item"; it must never claim the name column.
                    if (!isCodeHeader && rName < 0 && containsAny(h, "item name", "item", "description", "product", "name")) rName = colKey;
                    // Qty column: exact "Qty" wins. Ignore MinStock / Reorder Qty / Amount / price columns.
                    boolean badQty = containsAny(h, "min", "reorder", "re-order", "amount", "price", "value", "retail", "max");
                    int qs = 0;
                    if (!badQty) {
                        if (h.equals("qty") || h.equals("quantity") || h.equals("stock qty") || h.equals("stock") || h.equals("balance")) qs = 3;
                        else if (containsAny(h, "qty", "quantity", "balance", "stock")) qs = 1;
                    }
                    if (qs > qtyScore) { qtyScore = qs; rQty = colKey; }
                    int us = 0;
                    if (h.equals("unit") || h.equals("uom") || h.equals("u/o") || h.equals("units")) us = 2;
                    else if (containsAny(h, "unit", "uom")) us = 1;
                    if (us > unitScore) { unitScore = us; rUnit = colKey; }
                }
                if (rCode >= 0 && rName >= 0 && rQty >= 0) {
                    headerRow = r; codeCol = rCode; nameCol = rName; qtyCol = rQty; unitCol = rUnit;
                    break;
                }
            }
            if (headerRow < 0) throw new Exception("Need Item No, Item Name, Qty and Unit columns");
            if (unitCol < 0) unitCol = qtyCol + 1;

            JSONArray out = new JSONArray();
            for (int r = headerRow + 1; r < data.size(); r++) {
                Map<Integer,String> row = data.get(r);
                String code = clean(row.get(codeCol));
                String name = clean(row.get(nameCol));
                String qtyText = clean(row.get(qtyCol));
                String unit = clean(row.get(unitCol));
                if (code.isEmpty() && name.isEmpty()) continue;
                if (name.isEmpty() || qtyText.isEmpty()) continue;
                Double qty = parseNumber(qtyText);
                if (qty == null) continue;
                if (code.matches("\\d+") && code.length() < 4) code = leftPad(code, 4);
                JSONObject x = new JSONObject();
                x.put("c", code);
                x.put("n", name);
                x.put("q", qty);
                x.put("u", unit.isEmpty() ? "PCS" : unit.toUpperCase());
                out.put(x);
            }
            if (out.length() == 0) throw new Exception("No valid stock rows found");
            return out.toString();
        } finally {
            //noinspection ResultOfMethodCallIgnored
            temp.delete();
        }
    }

    private static boolean containsAny(String s, String... keys) {
        for (String k : keys) if (s.equals(k) || s.contains(k)) return true;
        return false;
    }

    private static String norm(String s) {
        return clean(s).toLowerCase().replaceAll("\\s+", " ");
    }

    private static String clean(String s) { return s == null ? "" : s.trim().replaceAll("\\s+", " "); }

    private static String leftPad(String s, int n) {
        StringBuilder b = new StringBuilder();
        for (int i=s.length(); i<n; i++) b.append('0');
        return b.append(s).toString();
    }

    private static Double parseNumber(String s) {
        try { return Double.parseDouble(s.replace(",", "").trim()); } catch (Exception e) { return null; }
    }

    private static int colIndex(String ref) {
        int n = 0;
        for (int i = 0; i < ref.length(); i++) {
            char ch = ref.charAt(i);
            if (ch < 'A' || ch > 'Z') break;
            n = n * 26 + (ch - 'A' + 1);
        }
        return n - 1;
    }

    private static Document xml(InputStream in) throws Exception {
        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
        f.setNamespaceAware(false);
        try { f.setExpandEntityReferences(false); } catch (Throwable ignored) {}
        return f.newDocumentBuilder().parse(in);
    }

    private static List<String> readSharedStrings(ZipFile zip) throws Exception {
        List<String> out = new ArrayList<>();
        ZipEntry e = zip.getEntry("xl/sharedStrings.xml");
        if (e == null) return out;
        Document d = xml(zip.getInputStream(e));
        NodeList si = d.getElementsByTagName("si");
        for (int i=0;i<si.getLength();i++) {
            Element el=(Element)si.item(i); StringBuilder b=new StringBuilder();
            NodeList ts=el.getElementsByTagName("t");
            for(int j=0;j<ts.getLength();j++) b.append(ts.item(j).getTextContent());
            out.add(b.toString());
        }
        return out;
    }

    private static String firstSheetPath(ZipFile zip) throws Exception {
        String defaultPath = "xl/worksheets/sheet1.xml";
        ZipEntry wb = zip.getEntry("xl/workbook.xml");
        ZipEntry rel = zip.getEntry("xl/_rels/workbook.xml.rels");
        if (wb == null || rel == null) return defaultPath;
        Document wbd=xml(zip.getInputStream(wb));
        NodeList sheets=wbd.getElementsByTagName("sheet");
        if(sheets.getLength()==0) return defaultPath;
        String rid=((Element)sheets.item(0)).getAttribute("r:id");
        Document rd=xml(zip.getInputStream(rel));
        NodeList rs=rd.getElementsByTagName("Relationship");
        for(int i=0;i<rs.getLength();i++){
            Element x=(Element)rs.item(i);
            if(rid.equals(x.getAttribute("Id"))){
                String t=x.getAttribute("Target");
                if(t.startsWith("/")) t=t.substring(1);
                if(t.startsWith("xl/")) return t;
                return "xl/"+t.replaceFirst("^/+", "");
            }
        }
        return defaultPath;
    }

    private static String cellValue(Element c, List<String> shared) {
        String type=c.getAttribute("t");
        NodeList v=c.getElementsByTagName("v");
        String raw=v.getLength()>0 ? v.item(0).getTextContent() : "";
        if("s".equals(type)){
            try{int i=(int)Double.parseDouble(raw); return i>=0&&i<shared.size()?shared.get(i):raw;}catch(Exception ignored){}
        }
        if("inlineStr".equals(type)){
            NodeList ts=c.getElementsByTagName("t"); return ts.getLength()>0?ts.item(0).getTextContent():"";
        }
        return raw;
    }
}
