# HB Store Hub Android

Separate Android app identity for the H.B Store order workflow.

## Important changes
- App name: **HB Store Hub**
- Android application ID: `com.hbstore.hub`
- New launcher icon (HB clipboard/check)
- Auto-update checks the public GitHub latest-release page (no GitHub API token required), avoiding API HTTP 403/rate-limit failures.
- This app does not fetch or prompt for the old `OrderSlip v29` release.
- Shopkeeper login opens the 3-shop dashboard:
  - H.B MALL
  - H.B KHARTHIYATH
  - H.B SOUQ
- Each shop has its own pending-order list.
- Orders open as a checklist and can be completed.
- Firebase project remains `hb-order-slip` for the cloud order/auth workflow.

## Order status flow
- **Pending** - shop sent the order.
- **Checked** - storekeeper opened it (shop gets a notification).
- **Completed** - storekeeper completed it (shop gets a notification).
- Storekeeper also gets a notification for every new order.
- Android back button steps back inside the storekeeper screens (order -> shop orders -> shops) instead of closing the app.
- Notifications now come from a background service (OrderWatchService, checks about every 45 s), so they arrive even when the app is closed. Allow notifications and "no battery restriction" when asked.
- New order from a shop: if an older order of the same shop was never sent, or was sent but not completed, the app asks whether to add the new items to it (Yes = merge, No = new order).


## v1.0.36 UI fixes
- Saved Orders no longer shows a Send/Sent action; only Open and Delete are available.
- PENDING / CHECKED / COMPLETED is displayed as a prominent status block.
- Opening a saved order enters the New-order editor; Back / ← New stays on the New tab.
- Background watcher notification is explicitly silent/minimal.
- Refreshed HB Store Hub launcher and notification icons.

## v1.0.40 fixes
- Auto-update no longer depends on `api.github.com`; it follows GitHub's `/releases/latest` redirect and downloads `HBStoreHub.apk` from the latest release.
- Update comparison uses the numeric suffix of `versionName`, so a locally built `1.0.x` release cannot be miscompared with a different Gradle `versionCode`.
- GitHub Actions now auto-builds and publishes a new GitHub Release whenever code is pushed to `main` or `master`; manual `workflow_dispatch` is still available.
- Automatic release tags continue from the highest existing `vNN` tag, so the next build after v38 becomes v39.
- Storekeeper shop cards highlight **Pending** orders as the main number; total historical orders are no longer the main highlight. Checked and Completed remain secondary counts.

- Shop Saved Orders sync only the current installation's submitted orders. Unsent drafts remain local to the device; reinstalling creates a new anonymous shop identity and does not pull old cloud history.


## v1.0.46 cloud sync / notifications / admin cleanup
- Shop Saved Orders uses the Firestore snapshot as the source of truth for submitted orders; admin cloud deletion now removes the same orders from the Shop Saved list.
- Shop status synchronization is based on stable `shopName`, so Pending → Checked → Completed does not get stuck after reinstall.
- Background order notifications are started after Firebase login and restored after reboot/app update; the native watcher also resolves the shop by stable `shopName` instead of the reinstall-sensitive anonymous UID.
- Added Admin → Cloud Orders management with shop-wise permanent deletion. Deleting a shop's orders removes them from Firestore, Storekeeper, and Shop on their next sync.


## v1.0.48 shop saved/sync fix
- Removed the Shop selector from the Saved tab. The Saved tab uses the shop selected on the New-order screen and never mixes saved orders from another shop.
- Shop cloud sync now queries orders by the authenticated installation's `shopUid`, matching Firestore rules directly and avoiding the previous "Missing or insufficient permissions" query failure.
- Local Saved Orders are filtered to the current shop.
- Shop reinstall intentionally starts with a new anonymous UID; old cloud orders from the removed installation are not pulled into the new installation.
