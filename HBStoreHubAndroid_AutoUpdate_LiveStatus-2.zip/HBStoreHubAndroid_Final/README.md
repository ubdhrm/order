# HB Store Hub Android

Separate Android app identity for the H.B Store order workflow.

## Important changes
- App name: **HB Store Hub**
- Android application ID: `com.hbstore.hub`
- New launcher icon (HB clipboard/check)
- Old GitHub auto-update check is completely disabled.
- This app does not fetch or prompt for the old `OrderSlip v29` release.
- Shopkeeper login opens the 3-shop dashboard:
  - H.B MALL
  - H.B KHARTHIYATH
  - H.B SOUQ
- Each shop has its own pending-order list.
- Orders open as a checklist and can be completed.
- Firebase project remains `hb-order-slip` for the cloud order/auth workflow.

## Order status flow
- **Pending** - shop sent the order.
- **Noted** - storekeeper opened it (shop gets a notification).
- **Completed** - storekeeper completed it (shop gets a notification).
- Storekeeper also gets a notification for every new order.
- Android back button steps back inside the storekeeper screens (order -> shop orders -> shops) instead of closing the app.
