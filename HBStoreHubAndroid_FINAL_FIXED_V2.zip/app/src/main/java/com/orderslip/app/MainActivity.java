package com.orderslip.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import java.util.ArrayList;
import android.content.Context;
import android.webkit.MimeTypeMap;
import android.widget.Toast;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.ViewGroup;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;
import org.json.JSONArray;
import org.xmlpull.v1.XmlPullParser;
import android.util.Xml;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Collections;
import java.io.ByteArrayInputStream;
import java.io.BufferedInputStream;

public class MainActivity extends Activity {
    static volatile boolean inForeground = false;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER = 1001;
    private static final int CAMERA_CAPTURE = 1002;
    private static final int VOICE_INPUT = 1003;
    private static final int CAMERA_PERMISSION = 1003;
    private Uri cameraUri;
    private boolean updateCheckRunning = false;
    private boolean updateDialogShown = false;
    private File pendingInstallApk;
    private static final String UPDATE_PAGE = "https://github.com/ubdhrm/order/releases/latest";
    private static final String UPDATE_APK_URL = "https://github.com/ubdhrm/order/releases/latest/download/HBStoreHub.apk";
    private static final int STOCK_EXCEL_PICKER = 1010;
    private static final String STOCK_PREFS = "hb_stock_excel";
    private static final String STOCK_JSON_KEY = "stock_json";
    private static final String STOCK_FILE_KEY = "stock_file";
    private static final String STOCK_TIME_KEY = "stock_time";

    private final class StockExcelBridge {
        @android.webkit.JavascriptInterface
        public void pickExcel() {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    "application/vnd.ms-excel",
                    "application/octet-stream"
            });
            startActivityForResult(i, STOCK_EXCEL_PICKER);
        }

        private String defaultStockJson() {
            try {
                InputStream in = getAssets().open("stock/stock_default.json");
                java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
                byte[] b = new byte[16384]; int n;
                while ((n=in.read(b))!=-1) out.write(b,0,n);
                in.close();
                return out.toString("UTF-8");
            } catch (Exception e) { return "[]"; }
        }

        private String activeStockJson() {
            android.content.SharedPreferences p = getSharedPreferences(STOCK_PREFS, MODE_PRIVATE);
            String saved = p.getString(STOCK_JSON_KEY, "");
            return (saved == null || saved.trim().isEmpty()) ? defaultStockJson() : saved;
        }

        @android.webkit.JavascriptInterface
        public String getStockMeta() {
            try {
                android.content.SharedPreferences p = getSharedPreferences(STOCK_PREFS, MODE_PRIVATE);
                boolean hasSaved = p.contains(STOCK_JSON_KEY);
                JSONObject o = new JSONObject();
                o.put("fileName", hasSaved ? p.getString(STOCK_FILE_KEY, "") : "Book1.xlsx (default stock)");
                o.put("updatedAt", hasSaved ? p.getLong(STOCK_TIME_KEY, 0) : 0);
                o.put("count", new JSONArray(activeStockJson()).length());
                return o.toString();
            } catch (Exception e) { return "{\"fileName\":\"Book1.xlsx (default stock)\",\"updatedAt\":0,\"count\":0}"; }
        }

        @android.webkit.JavascriptInterface
        public String getStockData() {
            return activeStockJson();
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        // v1.0.50: background sync uses WorkManager, not a foreground service.
        // Stop any watcher left over from an older app version.
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        // Force every load of the bundled page to come straight from the APK's
        // assets, never from WebView's own disk cache. Without this, updating
        // the app (installing a new APK over the old one, which does NOT clear
        // app data/cache the way a full uninstall does) can silently keep
        // serving an old cached copy of index.html/CSS even though the new
        // file is sitting right there in the new APK.
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return false; }
            // LOCAL FIRST: the Firebase SDK scripts used to be downloaded again on every
            // launch (cache is disabled above), so the app waited on the network before
            // showing anything. They're now bundled straight into the APK's assets
            // (see serveFirebaseSdkFromDisk), so this never touches the network.
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                WebResourceResponse local = serveFirebaseSdkFromDisk(r);
                return local != null ? local : super.shouldInterceptRequest(v, r);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                // Android WebView does not always expose the HTML capture="environment"
                // flag consistently. Show our own image chooser so both Camera and Gallery
                // work reliably inside the APK.
                showImageChooser();
                return true;
            }
        });
        webView.addJavascriptInterface(new ShareBridge(this), "AndroidShare");
        webView.addJavascriptInterface(new StockExcelBridge(), "StockExcelBridge");
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#123B47"));
        root.addView(webView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        // Keep the page below the status bar even if the system draws edge-to-edge.
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(0, insets.getSystemWindowInsetTop(), 0, 0);
            return insets;
        });
        setContentView(root);
        webView.clearCache(true);
        webView.loadUrl("file:///android_asset/index.html");
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1004);
        }
        // Do not compete with the first screen render; check for updates shortly after startup.
        new Handler(Looper.getMainLooper()).postDelayed(() -> checkForUpdate(), 1500);
    }

    private WebResourceResponse serveFirebaseSdkFromDisk(WebResourceRequest r) {
        try {
            if (r == null || r.getUrl() == null) return null;
            if (!"GET".equalsIgnoreCase(r.getMethod())) return null;
            String host = r.getUrl().getHost();
            String path = r.getUrl().getPath();
            if (host == null || path == null) return null;
            if (!host.equals("www.gstatic.com") || !path.startsWith("/firebasejs/") || !path.endsWith(".js")) return null;

            // BUNDLED FIRST: the exact 3 SDK files this build was compiled against are
            // shipped inside app/src/main/assets/firebase/ (fetched once at build time
            // by the fetchFirebaseSdk Gradle task - see app/build.gradle). Reading an
            // asset never touches the network or the filesystem cache below, so this
            // is the normal path on every launch, reinstall, and storage clear.
            String assetName = path.substring(path.lastIndexOf('/') + 1);
            try {
                return new WebResourceResponse("application/javascript", "UTF-8",
                        getAssets().open("firebase/" + assetName));
            } catch (IOException notBundled) {
                // Falls through to the network-backed disk cache below. This only
                // happens if index.html's SDK version was bumped without re-running
                // a build that re-populates assets/firebase/ for the new version.
            }

            File dir = new File(getFilesDir(), "sdk_cache");
            if (!dir.exists() && !dir.mkdirs()) return null;
            File f = new File(dir, path.replace('/', '_'));
            if (!f.exists() || f.length() < 1000) {
                HttpURLConnection c = (HttpURLConnection) new URL(r.getUrl().toString()).openConnection();
                c.setConnectTimeout(8000);
                c.setReadTimeout(20000);
                if (c.getResponseCode() != 200) return null;
                File tmp = new File(dir, f.getName() + ".tmp");
                InputStream in = c.getInputStream();
                FileOutputStream out = new FileOutputStream(tmp);
                try {
                    byte[] buf = new byte[16384];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                } finally {
                    try { out.close(); } catch (Exception ignored) {}
                    try { in.close(); } catch (Exception ignored) {}
                }
                if (f.exists()) f.delete();
                if (!tmp.renameTo(f)) return null;
            }
            return new WebResourceResponse("application/javascript", "UTF-8", new FileInputStream(f));
        } catch (Exception e) {
            return null; // anything odd: let WebView fetch it from the network as before
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
if (requestCode == STOCK_EXCEL_PICKER) {
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {}
        new Thread(() -> {
            try {
                final JSONArray rows = parseStockXlsx(uri);
                if (rows.length() == 0) throw new Exception("No Item Name / Item Code rows found in the Excel file.");
                String fileName = queryDisplayName(uri);
                if (fileName == null || fileName.trim().isEmpty()) fileName = "Stock Excel";
                getSharedPreferences(STOCK_PREFS, MODE_PRIVATE).edit()
                        .putString(STOCK_JSON_KEY, rows.toString())
                        .putString(STOCK_FILE_KEY, fileName)
                        .putLong(STOCK_TIME_KEY, System.currentTimeMillis())
                        .apply();
                final String js = "window.onStockExcelImported && window.onStockExcelImported(" +
                        JSONObject.quote(fileName) + "," + rows.length() + ");";
                runOnUiThread(() -> webView.evaluateJavascript(js, null));
            } catch (Exception e) {
                final String msg = e.getMessage() == null ? "Could not read Excel file" : e.getMessage();
                runOnUiThread(() -> webView.evaluateJavascript(
                        "window.onStockExcelImportFailed && window.onStockExcelImportFailed(" + JSONObject.quote(msg) + ");", null));
            }
        }).start();
        } else if (requestCode == FILE_CHOOSER) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    results = new Uri[n];
                    for (int i = 0; i < n; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            if (fileCallback != null) { fileCallback.onReceiveValue(results); fileCallback = null; }
        } else if (requestCode == VOICE_INPUT) {
            String spoken = "";
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (r != null && !r.isEmpty()) spoken = r.get(0);
            }
            sendVoiceToPage(spoken);
        } else if (requestCode == CAMERA_CAPTURE) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && cameraUri != null) results = new Uri[]{cameraUri};
            if (fileCallback != null) { fileCallback.onReceiveValue(results); fileCallback = null; }
            cameraUri = null;
        }
    }


    /** Starts Android's native speech recognizer and returns the text through sendVoiceToPage(). */
    public void startVoice(final String lang) {
        try {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            if (lang != null && !lang.trim().isEmpty()) {
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang.trim());
            }
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak");
            startActivityForResult(i, VOICE_INPUT);
        } catch (Exception e) {
            Toast.makeText(this, "Voice input is not available on this device", Toast.LENGTH_SHORT).show();
        }
    }

    /** Delivers native speech text back to the bundled page. */
    private void sendVoiceToPage(final String spoken) {
        final String value = spoken == null ? "" : spoken;
        runOnUiThread(() -> {
            if (webView == null) return;
            String js = "(function(){var s=" + JSONObject.quote(value) + ";"
                    + "try{if(window.onNativeVoiceResult) window.onNativeVoiceResult(s);"
                    + "else if(window.onVoiceResult) window.onVoiceResult(s);"
                    + "window.dispatchEvent(new CustomEvent('hbvoice',{detail:s}));}catch(e){}})();";
            webView.evaluateJavascript(js, null);
        });
    }

    /** Backward-compatible startup check used by the delayed startup callback. */
    private void checkForUpdate() {
        checkForUpdate(false);
    }

    /** Opens the public latest-release page when the user asks for an update check. */
    public void checkForUpdate(final boolean manual) {
        runOnUiThread(() -> {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(UPDATE_PAGE));
                startActivity(i);
            } catch (Exception e) {
                Toast.makeText(this, "Could not open update page", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /** Returns the display name of a document Uri. */
    private String queryDisplayName(Uri uri) {
        if (uri == null) return null;
        android.database.Cursor c = null;
        try {
            c = getContentResolver().query(uri, new String[]{"_display_name"}, null, null, null);
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return null;
    }

    /** Reads the first worksheet of a normal XLSX file and maps common stock columns to n/c/b/u. */
    private JSONArray parseStockXlsx(Uri uri) throws Exception {
        if (uri == null) throw new Exception("No Excel file selected.");

        File tmp = new File(getCacheDir(), "stock_import_" + System.currentTimeMillis() + ".xlsx");
        try (InputStream in = getContentResolver().openInputStream(uri);
             FileOutputStream out = new FileOutputStream(tmp)) {
            if (in == null) throw new Exception("Could not open Excel file.");
            byte[] buf = new byte[32768];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        }

        ZipFile zip = null;
        try {
            zip = new ZipFile(tmp);
            List<String> shared = readSharedStrings(zip);

            String sheetPath = "xl/worksheets/sheet1.xml";
            ZipEntry workbook = zip.getEntry("xl/workbook.xml");
            if (workbook != null) {
                try (InputStream in = zip.getInputStream(workbook)) {
                    XmlPullParser p = Xml.newPullParser();
                    p.setInput(in, "UTF-8");
                    boolean inSheets = false;
                    String relId = null;
                    for (int ev = p.getEventType(); ev != XmlPullParser.END_DOCUMENT; ev = p.next()) {
                        if (ev == XmlPullParser.START_TAG && "sheet".equals(p.getName())) {
                            relId = p.getAttributeValue("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id");
                            if (relId == null) relId = p.getAttributeValue(null, "r:id");
                            break;
                        }
                    }
                    if (relId != null) {
                        ZipEntry rels = zip.getEntry("xl/_rels/workbook.xml.rels");
                        if (rels != null) {
                            try (InputStream rin = zip.getInputStream(rels)) {
                                XmlPullParser rp = Xml.newPullParser();
                                rp.setInput(rin, "UTF-8");
                                for (int ev = rp.getEventType(); ev != XmlPullParser.END_DOCUMENT; ev = rp.next()) {
                                    if (ev == XmlPullParser.START_TAG && "Relationship".equals(rp.getName())) {
                                        String id = rp.getAttributeValue(null, "Id");
                                        if (relId.equals(id)) {
                                            String target = rp.getAttributeValue(null, "Target");
                                            if (target != null) {
                                                target = target.replaceFirst("^/+", "");
                                                if (target.startsWith("worksheets/")) sheetPath = "xl/" + target;
                                                else if (target.startsWith("xl/")) sheetPath = target;
                                                else sheetPath = "xl/worksheets/" + target;
                                            }
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            ZipEntry sheet = zip.getEntry(sheetPath);
            if (sheet == null) throw new Exception("Excel worksheet not found.");

            List<Map<Integer,String>> rows = new ArrayList<>();
            try (InputStream in = zip.getInputStream(sheet)) {
                XmlPullParser p = Xml.newPullParser();
                p.setInput(in, "UTF-8");
                Map<Integer,String> row = null;
                int col = 0;
                String type = null;
                StringBuilder value = new StringBuilder();
                boolean inV = false, inT = false, inInline = false;

                for (int ev = p.getEventType(); ev != XmlPullParser.END_DOCUMENT; ev = p.next()) {
                    if (ev == XmlPullParser.START_TAG) {
                        String name = p.getName();
                        if ("row".equals(name)) {
                            row = new HashMap<>();
                        } else if ("c".equals(name) && row != null) {
                            String ref = p.getAttributeValue(null, "r");
                            col = columnNumber(ref);
                            type = p.getAttributeValue(null, "t");
                            value.setLength(0);
                            inInline = "inlineStr".equals(type);
                        } else if ("v".equals(name) && row != null) {
                            inV = true;
                            value.setLength(0);
                        } else if ("t".equals(name) && row != null && inInline) {
                            inT = true;
                            value.setLength(0);
                        }
                    } else if (ev == XmlPullParser.TEXT) {
                        if (inV || inT) value.append(p.getText());
                    } else if (ev == XmlPullParser.END_TAG) {
                        String name = p.getName();
                        if ("v".equals(name)) {
                            inV = false;
                        } else if ("t".equals(name)) {
                            inT = false;
                        } else if ("c".equals(name) && row != null) {
                            String raw = value.toString();
                            if ("s".equals(type)) {
                                try {
                                    int idx = Integer.parseInt(raw.trim());
                                    raw = idx >= 0 && idx < shared.size() ? shared.get(idx) : "";
                                } catch (Exception ignored) { raw = ""; }
                            }
                            row.put(col, raw);
                        } else if ("row".equals(name) && row != null) {
                            rows.add(row);
                            row = null;
                        }
                    }
                }
            }

            if (rows.isEmpty()) return new JSONArray();

            Map<Integer,String> header = rows.get(0);
            int nameCol = findHeader(header, "item name", "item", "name", "product name", "description");
            int codeCol = findHeader(header, "item code", "code", "barcode", "sku", "item no", "item number");
            int brandCol = findHeader(header, "brand", "brand name");
            int unitCol = findHeader(header, "unit", "uom", "unit name");

            // If the sheet has no recognizable header, use the first four populated columns.
            if (nameCol < 0 || codeCol < 0) {
                List<Integer> cols = new ArrayList<>(header.keySet());
                Collections.sort(cols);
                if (nameCol < 0 && !cols.isEmpty()) nameCol = cols.get(0);
                if (codeCol < 0 && cols.size() > 1) codeCol = cols.get(1);
                if (brandCol < 0 && cols.size() > 2) brandCol = cols.get(2);
                if (unitCol < 0 && cols.size() > 3) unitCol = cols.get(3);
            }

            JSONArray out = new JSONArray();
            for (int i = 1; i < rows.size(); i++) {
                Map<Integer,String> r = rows.get(i);
                String n = cleanCell(r.get(nameCol));
                String c = cleanCell(r.get(codeCol));
                if (n.isEmpty() && c.isEmpty()) continue;
                JSONObject o = new JSONObject();
                o.put("n", n);
                o.put("c", c);
                o.put("b", cleanCell(r.get(brandCol)));
                o.put("u", cleanCell(r.get(unitCol)));
                out.put(o);
            }
            return out;
        } finally {
            if (zip != null) try { zip.close(); } catch (Exception ignored) {}
            if (tmp.exists()) tmp.delete();
        }
    }

    private List<String> readSharedStrings(ZipFile zip) throws Exception {
        List<String> out = new ArrayList<>();
        ZipEntry e = zip.getEntry("xl/sharedStrings.xml");
        if (e == null) return out;
        try (InputStream in = zip.getInputStream(e)) {
            XmlPullParser p = Xml.newPullParser();
            p.setInput(in, "UTF-8");
            StringBuilder s = new StringBuilder();
            boolean inT = false;
            for (int ev = p.getEventType(); ev != XmlPullParser.END_DOCUMENT; ev = p.next()) {
                if (ev == XmlPullParser.START_TAG && "t".equals(p.getName())) {
                    inT = true;
                } else if (ev == XmlPullParser.TEXT && inT) {
                    s.append(p.getText());
                } else if (ev == XmlPullParser.END_TAG && "t".equals(p.getName())) {
                    inT = false;
                } else if (ev == XmlPullParser.END_TAG && "si".equals(p.getName())) {
                    out.add(s.toString());
                    s.setLength(0);
                }
            }
        }
        return out;
    }

    private static int columnNumber(String ref) {
        if (ref == null || ref.isEmpty()) return 0;
        int n = 0;
        for (int i = 0; i < ref.length(); i++) {
            char ch = ref.charAt(i);
            if (ch < 'A' || ch > 'Z') break;
            n = n * 26 + (ch - 'A' + 1);
        }
        return n - 1;
    }

    private static String cleanCell(String s) {
        return s == null ? "" : s.trim();
    }

    private static int findHeader(Map<Integer,String> row, String... names) {
        for (Map.Entry<Integer,String> e : row.entrySet()) {
            String h = cleanCell(e.getValue()).toLowerCase(java.util.Locale.US);
            for (String n : names) {
                if (h.equals(n) || h.contains(n)) return e.getKey();
            }
        }
        return -1;
    }

    private void showImageChooser() {
        final String[] choices = new String[]{"📷 Camera", "🖼 Gallery"};
        new AlertDialog.Builder(this)
                .setTitle("Add photo")
                .setItems(choices, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) startCamera(); else openPicker();
                    }
                })
                .setOnCancelListener(dialog -> cancelFileChooser())
                .show();
    }

    private void openPicker() {
        try {
            Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            pick.addCategory(Intent.CATEGORY_OPENABLE);
            pick.setType("image/*");
            pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
            startActivityForResult(pick, FILE_CHOOSER);
        } catch (Exception e) {
            // Some devices do not provide ACTION_OPEN_DOCUMENT; fall back to GET_CONTENT.
            try {
                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("image/*");
                startActivityForResult(pick, FILE_CHOOSER);
            } catch (Exception ignored) { cancelFileChooser(); }
        }
    }

    private void cancelFileChooser() {
        if (fileCallback != null) {
            fileCallback.onReceiveValue(null);
            fileCallback = null;
        }
    }

    private void startCamera() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION);
            return;
        }
        launchCamera();
    }

    private void launchCamera() {
        try {
            File dir = new File(getCacheDir(), "camera");
            if (!dir.exists()) dir.mkdirs();
            File photo = new File(dir, "photo_" + System.currentTimeMillis() + ".jpg");
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", photo);
            Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            cam.setClipData(ClipData.newRawUri("", cameraUri));
            cam.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            startActivityForResult(cam, CAMERA_CAPTURE);
        } catch (Exception e) {
            openPicker();   // no camera app -> let the user pick a photo instead
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) launchCamera();
            else openPicker();
        }
    }

    @Override public void onBackPressed() {
        // Let the page go one step back first (order -> shop orders -> shops); close the app only from the top screen.
        webView.evaluateJavascript(
                "(function(){try{return !!(window.hbHandleBack && window.hbHandleBack());}catch(e){return false;}})()",
                value -> {
                    if ("true".equals(value)) return;
                    if (webView.canGoBack()) webView.goBack(); else finish();
                });
    }
}
