# HB Store Hub Android

Separate Android app identity for the H.B Store order workflow.

## Important changes
- App name: **HB Store Hub**
- Android application ID: `com.hbstore.hub`
- New launcher icon (HB clipboard/check)
- Auto-update checks the public GitHub latest-release page (no GitHub API token required), avoiding API HTTP 403/rate-limit failures.
- This app does not fetch or prompt for the old `OrderSlip v29` release.
- Shopkeeper login opens the 3-shop dashboard:
  - H.B MALL
  - H.B KHARTHIYATH
  - H.B SOUQ
- Each shop has its own pending-order list.
- Orders open as a checklist and can be completed.
- Firebase project remains `hb-order-slip` for the cloud order/auth workflow.

## Order status flow
- **Pending** - shop sent the order.
- **Checked** - storekeeper opened it (shop gets a notification).
- **Completed** - storekeeper completed it (shop gets a notification).
- Storekeeper also gets a notification for every new order.
- Android back button steps back inside the storekeeper screens (order -> shop orders -> shops) instead of closing the app.
- Background order/status sync uses Android WorkManager without a persistent foreground-service notification. Actual order notifications may still be shown when a change is detected.
- New order from a shop: if an older order of the same shop was never sent, or was sent but not completed, the app asks whether to add the new items to it (Yes = merge, No = new order).


## v1.0.36 UI fixes
- Saved Orders no longer shows a Send/Sent action; only Open and Delete are available.
- PENDING / CHECKED / COMPLETED is displayed as a prominent status block.
- Opening a saved order enters the New-order editor; Back / ← New stays on the New tab.
- There is no persistent background-watcher notification.
- Refreshed HB Store Hub launcher and notification icons.

## v1.0.40 fixes
- Auto-update no longer depends on `api.github.com`; it follows GitHub's `/releases/latest` redirect and downloads `HBStoreHub.apk` from the latest release.
- Update comparison uses the numeric suffix of `versionName`, so a locally built `1.0.x` release cannot be miscompared with a different Gradle `versionCode`.
- GitHub Actions now auto-builds and publishes a new GitHub Release whenever code is pushed to `main` or `master`; manual `workflow_dispatch` is still available.
- Automatic release tags continue from the highest existing `vNN` tag, so the next build after v38 becomes v39.
- Storekeeper shop cards highlight **Pending** orders as the main number; total historical orders are no longer the main highlight. Checked and Completed remain secondary counts.

- Shop Saved Orders sync only the current installation's submitted orders. Unsent drafts remain local to the device; reinstalling creates a new anonymous shop identity and does not pull old cloud history.


## v1.0.46 cloud sync / notifications / admin cleanup
- Shop Saved Orders uses the Firestore snapshot as the source of truth for submitted orders; admin cloud deletion now removes the same orders from the Shop Saved list.
- Shop status synchronization is based on stable `shopName`, so Pending → Checked → Completed does not get stuck after reinstall.
- Background order notifications are started after Firebase login and restored after reboot/app update; the native watcher also resolves the shop by stable `shopName` instead of the reinstall-sensitive anonymous UID.
- Added Admin → Cloud Orders management with shop-wise permanent deletion. Deleting a shop's orders removes them from Firestore, Storekeeper, and Shop on their next sync.


## v1.0.48 shop saved/sync fix
- Removed the Shop selector from the Saved tab. The Saved tab uses the shop selected on the New-order screen and never mixes saved orders from another shop.
- Shop cloud sync now queries orders by the stable Admin-assigned `shopName`, so orders created by older app/login UIDs remain visible after an app update or re-login. Firestore rules must be deployed from `FIREBASE_FIRESTORE_RULES.txt` so shops can read their own orders by `shopName`.
- Local Saved Orders are filtered to the current shop.
- Shop reinstall intentionally starts with a new anonymous UID; old cloud orders from the removed installation are not pulled into the new installation.


## v1.0.50 background sync
- Background order/status sync uses Android WorkManager instead of a foreground service.
- No persistent “Watching for order updates” notification is shown.
- An immediate one-time sync is scheduled after login, followed by periodic background sync when network is available.
- While the app is open, Firestore listeners continue to provide live updates.
- Actual order update notifications are still allowed; only the persistent service-running notification is removed.


## v1.0.57 shop picker + locked shop
- Shop tab on the login screen now has a **Select your shop** dropdown (H.B MALL / H.B KHARTHIYATH / H.B SOUQ). No ID or password for shops.
- The first entry locks this phone (Firebase anonymous UID) to that shop: `users/{uid}.shopName`. Next launches go straight in.
- The New Order screen shows the shop as locked (read-only). **Request shop change** sends `users/{uid}.changeRequest` to Admin.
- Admin dashboard → **Shop change requests** → Approve (updates `shopName`; the shop phone reloads into the new shop) or Reject.
- Firestore rules updated: a shop can no longer change its own `shopName`; Admin can read `users`. **Publish the new FIREBASE_FIRESTORE_RULES.txt.**
- Note: reinstalling the app creates a new anonymous UID, so the phone is asked to pick a shop again.

## v1.0.58 shop completed-order view
- Completed orders opened from the Shop's Saved tab now show a clean read-only summary: "Order completed" banner with counts, one card per item (name, qty + unit, ✓ Checked / ✕ Out of stock), size rows for sized items, the shop's own note, storekeeper note only if one was written, and the item photo if any.
- No editable-looking Qty/Unit boxes and no empty "Your notes (storekeeper only)" box.
- Storekeeper screens and Cancelled orders are unchanged.

## v1.0.59 faster start for locked shop phones
- A phone already locked to a shop enters straight away using the cached shop (no Firestore read before opening), and the login card is hidden while Firebase starts, so the "Select your shop" screen no longer shows for ~4 seconds.
- The shop is still verified with Firestore in the background; if Admin approved a change or removed the profile, the app reloads accordingly.

## v1.0.60 faster start for Admin / Storekeeper
- After a successful staff login the role is cached on the phone. Next launches open the Admin / Storekeeper screen straight away (login card hidden while Firebase starts).
- The role is re-checked with Firestore in the background; if it was changed or removed, the app reloads or signs out.
- Logout clears the cache.

## v1.0.61 New arrivals popup
- Admin dashboard → **New arrivals popup**: create a popup with title, details text and up to 4 photos; preview it; publish; hide/show or delete published ones.
- Shops see unseen popups full screen right after opening the app (one after another, "Next"/"Close"). The ✕ or Android Back closes it. A popup is shown once per phone; a **New arrivals** button under the shop field reopens any visible popup.
- Data is stored in the Firestore `announcements` collection (photos compressed and stored inside the document). **Publish the updated FIREBASE_FIRESTORE_RULES.txt** (adds `announcements`: read for signed-in users, write for Admin only).

## v1.0.62 popup shows every time
- New-arrivals popups now show **every time the shop opens the app** until Admin hides or deletes them.
- Admin form has "Show only once per phone" (off by default) for popups that should appear a single time.
- The shop's New arrivals button still reopens any visible popup at any time.

## v1.0.63 Storekeeper can manage New arrivals
- Storekeeper dashboard has an **🆕 Arrivals** button opening the same create / preview / hide / delete screen as Admin.
- Firestore rules for `announcements`: read for signed-in users, write for Admin **and Storekeeper**. Publish the updated rules.
- Storekeeper does not get the popup itself; only Shops do.

## v1.0.64 start-up logo + About us
- While the app starts (instead of a blank cream screen) the HB logo is shown centred.
- Shop → Saved tab, at the very bottom (below Check for update / Send feedback): **About us** screen with "What is this app for?", "How it works", "App features" and "Created by UBAID".
- Android Back closes the About screen.

## v1.0.65 delivery confirmation ("Sending…")
- After Send, the order shows **Sending…** until Firebase confirms it received the order. Only then it becomes **Sent · waiting** (was "Pending"), then Checked / Completed.
- If the app is closed before confirmation, the order shows **Checking…** on next start and is verified against the cloud. If it is really not in the cloud it shows **Not sent** with **Send again** / **Delete**.
- The New form is reset as soon as Send starts (no double-send); the order lives in Saved while sending. If sending fails it goes back to Draft.
- Orders sent by older versions are unaffected.

## v1.0.68 Admin can no longer add orders
- The "Add order" button is removed from the Admin screen. Orders can only be created by shops.

## v1.0.67 Add-order safety: shop must be selected, duplicate warning, order origin stamp
- Admin "Add order": shop dropdown now starts on "Select shop" (before, the first shop was silently pre-selected).
- Admin "Add order": warns if the exact same items were already sent to any shop in the last 24h.
- Every new order now records createdVia (admin-add / shop-app), createdByUid and createdByRole; the Admin order list shows "added by admin" or "from shop phone".

## v1.0.66 sent orders are view-only + add / remove items
- Opening a **sent** order (Waiting for storekeeper / Checked) from Saved now shows a **view-only screen** (no editable form, no Send button), so it can no longer create a duplicate order.
- On that screen: **＋ Add item**, **Remove** (per item, even if the storekeeper already checked it) and **Cancel order**.
- **Add item** opens the normal item form in "Adding items to Order #N" mode; the items are appended to the SAME cloud order (same order ID). Items show **Sending…** until Firebase confirms, or **Not sent** with **Send again** / **Discard**. Adding is idempotent (an item ID is never added twice).
- **Remove** only flags the item (`removedByShop`), never deletes it. The shop sees "Removed by you"; the storekeeper sees a **REMOVED BY SHOP** card (red "put it back in stock" if it was already checked, grey otherwise) and a notification. Removed items do not block **Complete**.
- Each item shows its own status: Sending… / Waiting for storekeeper / Checked / Out of stock / Removed by you.
- Status wording: "Sent · waiting" is now **Waiting for storekeeper**.
- Completed and Cancelled orders are locked (no Add / Remove / Cancel); the list no longer shows Cancel on them.
- No Firestore rules change needed.


## Admin Control Center — functional implementation
The Admin redesign now includes Firebase-backed:
- Dashboard counts from live `orders` and `feedback`
- Shop list and order status summaries
- Order search/filter and permanent delete
- Real staff login creation (Admin/Storekeeper) using a secondary Firebase Auth app
- Staff role and active/disabled profile management
- Reports calculated from live orders
- Real Admin activity audit log in `activityLog`
- Firebase-persisted Admin settings in `settings/admin`
- Announcement publish/toggle/delete actions recorded in the audit log

### Firestore rules
Deploy the updated `FIREBASE_FIRESTORE_RULES.txt` in Firebase Console / Firestore Rules. The new rules add Admin-only access for `activityLog` and `settings`.

## Startup speed: instant dashboard from cached login
- The app no longer waits for the Firebase Auth SDK to finish restoring its own session before showing the dashboard. If this phone has a verified identity cached from a past login, it opens straight to that dashboard immediately and the real Firebase Auth check runs quietly behind it, correcting course (back to the login card) only if that trust turns out to be wrong.
- For a Shop login, the live Firestore order listener now starts at the same time as the cached dashboard, instead of waiting for Firebase's session restore to confirm the account first.
- Firebase SDK files (`firebase-app-compat.js`, `firebase-auth-compat.js`, `firebase-firestore-compat.js`) are now bundled into the APK's assets at build time (`fetchFirebaseSdk` Gradle task, pinned to `10.14.1`) instead of being downloaded and cached to disk on first run, removing a network dependency from cold start and reinstalls entirely.

## Storekeeper dashboard: reduce redraw lag
- The live order listener used to redraw the whole Storekeeper dashboard (every stat card, shop card, and order row) on every single order change from any shop -- during a busy stretch with several shops updating orders close together, that meant several full-screen rebuilds per second.
- The redraw is now debounced (~200ms, batching rapid changes into one redraw) with an 800ms max-wait safeguard so a continuous stream of changes still forces a redraw regularly instead of stalling indefinitely.
- Order data and the "New order" / cancellation notifications are unaffected -- they still update and fire immediately. Only the dashboard screen redraw itself is batched.

## Storekeeper stock balance / item number lookup
- Storekeeper order rows now look up item number and stock quantity from the 13-Sep-2026 stock snapshot supplied in `Book1.xlsx`.
- Sized items resolve each size to its own stock item number and balance.
- DZN and PCS are converted at 1 DZN = 12 PCS when comparing an order quantity with stock; other stock units are kept as-is.
- The last stock snapshot is cached on-device and replaced only when the embedded stock version changes, so a restart does not erase the current stock data.
- Shop-side screens and order-entry behavior are not changed by this stock lookup.

## v1.0.109 Storekeeper home-screen widget
- New **HB Orders** widget (long-press home screen -> Widgets -> HB Store Hub). Resizable list like the WhatsApp widget.
- Header shows "N new orders - M open"; each row shows shop, order number, time and a NEW / CHECKED tag. Tap opens the app.
- Updates instantly while the app is open (Firestore listener) and via the background sync (about every 15 min) when the app is closed. Logging out clears it.

## v1.0.110 Back from order goes to home screen
- Storekeeper: Back (Android back or the top-left arrow) on an opened order now sends the app to the phone's home screen instead of stepping to the shop's order list.

## v1.0.111 Storekeeper order list simplified
- Shop order list (Storekeeper) is now a plain list: serial no. | order no. | status.
- Removed the Pending/Checked/Packing/Completed cards, the filter chips, the white card panel, and the date/items/shop text on each row.
- Tapping a row still opens the order. Search now matches order no.

## v1.0.112 Widget shows PACKING status
- Storekeeper widget now shows the real status: NEW / CHECKED / PACKING (packing orders were wrongly shown as CHECKED).

## v1.0.113 Checked items turn green
- Storekeeper order screen: an item card that is checked (all sizes checked for sized items) is fully green. For sized items that are only partly checked, each checked size row is green. Out-of-stock items keep their red style.

## v1.0.114 Back from order -> Storekeeper home
- Back (Android back or the top-left arrow) on an opened order saves ticks/notes and returns to the main Storekeeper home screen (active orders). It no longer sends the app to the phone home screen (this replaces the v1.0.110 behaviour). Back on the Storekeeper home still exits the app.

## v1.0.115 Storekeeper bottom bar alignment
- The WebView now respects the system navigation-bar inset (bottom padding), so the bottom bar (Orders / Arrivals / Stock / Feedback) is no longer cut off.
- Bottom bar made slightly more compact (label 13px, icon pill 72x32) and top-aligned so icons and labels line up evenly.

## v1.0.116 Storekeeper WhatsApp share as text (no PDF)
- The WhatsApp button on the storekeeper order screen now sends plain text, not a PDF.
- Format: `*SHOP* · Order #NO`, then `1. Item – qty unit ✓ Checked`, sized items with one line per size, and `Note: ... | Item no ...` lines.
- Out-of-stock items/sizes are struck through (`~ ... ~`) with "Out of stock".

## v1.0.117 Item no in WhatsApp text
- The WhatsApp text now includes the stock Item no on each line (per size for sized items), e.g. `1. SHAWL SQR – 25 dzn ✓ Checked · Item no 0561`.

## v1.0.118 WhatsApp text: all items, no tick on out-of-stock, struck names
- WhatsApp text lists every item (checked, out of stock, and not-yet-marked ones).
- Out-of-stock items have no tick and are struck through, including the item name (for sized items the name is struck when every size is out of stock; otherwise only the out-of-stock size lines).

## v1.0.119 Companies shops can see (item-name access)
- New Storekeeper tab **Items**: add / remove the companies (first word of the item name, e.g. SHA, ISM, AGREE) that shops may see. Typing suggests companies from the Excel with item counts; Save writes to Firestore `shopCatalog/allowed`.
- Shops only get item-name suggestions (names only, no codes) for those companies. With no companies added, shops get no suggestions (they can still type free text). Storekeeper and Admin still search the full catalog.
- **Publish the updated `FIREBASE_FIRESTORE_RULES.txt`** in the Firebase console (new `shopCatalog` rule) or saving/reading will be denied.
- Note: the bundled item list is still inside the APK; shops just can't see it in the app.

## v1.0.120 Sizes in shop name suggestions
- On the shop side, each item-name suggestion now shows its available sizes as small chips under the name (e.g. 3-4, 5-6, 7-8, M, L). Storekeeper/Admin suggestions are unchanged.

## v1.0.121 Shop: qty for every size right from the suggestion
- Shop taps an item-name suggestion that has sizes (e.g. SHA BOYS T-SHIRT) -> a sheet lists ALL its sizes (1-2 ... 15-16) with a qty box each and ONE unit (Pcs/Dzn/Box) for all. Add saves it as a single item ("3-4:1 · 5-6:1 · 7-8:1") and moves on to the next item row. Sizes left blank are not ordered.
- Items without sizes behave as before. The storekeeper view is unchanged (one row per size).

## v1.0.127 Arrivals: 10 collages per screen
New Arrivals screen shows all photos of each upload in its collage, sized so 10 collages (2 x 5) fit one screen; the rest scroll.

## v1.0.126 New Arrivals screen
Shop: 'New arrivals' button removed from the item-entry screen. Home New Arrivals card / bell now opens a separate screen with one collage card per upload; tap a card to open it (with the Message option).

## v1.0.125 Storekeeper bottom nav fix
Empty white send-bar no longer covers the storekeeper home bottom nav (labels were cut off). Dashboard is clean.

## v1.0.124 Numeric sizes 24-56
Size list now goes 24 to 56 (48, 50, 52, 54, 56 added), so suggestions with those sizes open the size quantity popup.

## v1.0.123 Auto-merge into previous order
New order from a shop is now added automatically to the previous order if packing has not started (popup tells the shop). If packing started, it goes as a new order.

## v1.0.122 More size formats
- Sized-item handling (shop qty-per-size sheet, storekeeper size rows, WhatsApp text) now also recognises ranges: letter ranges (S-XL, 2XL-3XL, S-L, M-XL), baby ages (0-6, 6-12, 12-18, 18-24) and other number ranges (2-3 ... 16-17, 26-36, ...).
- Still not covered: single big numbers (48-64) and K sizes above 30K (32K-40K).


## v1.0.128 Home New Arrivals: last 24 hours only
- Home card shows only arrivals added in the last 24h; newest first (new one replaces older photos); card hides after 1 day.
- Full list stays under the bell.


## v1.0.129 Arrivals card stays, badge only for last 24h
- Card no longer hides after 1 day; only the count badge disappears when nothing new in 24h.


## v1.0.130 Storekeeper compact teal theme
- New Orders home (Active/History), Shops tab, per-shop orders screen, 6-tab bottom nav.


## v1.0.131 Checklist teal compact theme
- Checklist header, packing banner, item cards, size rows restyled (CSS).

## v1.0.132 storekeeper teal pages
- Feedback, New arrivals and Shop items (Storekeeper) now use the same teal header, rounded cards and bottom nav as Orders / Shops / Checklist.
- Fixed: Save / WhatsApp / Complete order bar was hidden on the storekeeper checklist (CSS rule for the home screen also matched the checklist).

## v1.0.133 bigger storekeeper UI
- Larger header, tabs, list rows, bottom nav, checklist text/buttons, Feedback / New arrivals / Shop items text.
- Status bar on storekeeper screens is teal (was blue on the checklist).

## v1.0.136
- Storekeeper WhatsApp share: blank line between item name and size list.

## v1.0.135
- Storekeeper packing checklist: item cards ~15% bigger (uniform zoom, layout unchanged).

## v1.0.134
- Checklist screens (view only / packing / completed) back to the original compact size; other storekeeper pages stay bigger.


## v1.0.203 note reply tracking
- Storekeeper's whole-order note now sends a phone notification to the shop even when the app is closed (same background sync as the other order notifications; Android checks about every 15 min when the app is closed, and immediately while it is open).
- Shop: orders waiting for a reply show a red **Reply pending** tag and red dot on the home screen (Last order card, Recent Orders, Saved Orders tile). In the Orders list the status chip becomes **Reply pending**. It clears as soon as the shop replies.
- Storekeeper: each order with a note shows **Sent · Not seen / Seen <time> / Replied**. "Seen" is written when the shop opens the order's note panel; There is no time limit: it stays "Not seen" until the shop opens it. The opened order also shows this status line above the note thread.
- Storekeeper also gets a notification when a shop replies to a note.
- **Firestore rules must be re-published** (`FIREBASE_FIRESTORE_RULES.txt`): shops may now write `noteSeenAt` on their own order. Without this, "Seen" never turns on.
- New-order Catalog strip: tapping an item now opens that item's page directly (swipe works across the strip items). Back returns to the normal Catalog screen. "View all" still opens the Catalog home.
- New order -> "Adding to your active order" banner now has **View ›**; tapping it opens a read-only popup of that order (items, qty, per-item Checked / Out of stock / Pending, storekeeper note).


## v1.0.205 (incl. v1.0.204) reply alert + hidden note box while packing
- Storekeeper: when a shop replies to a note, the order shows a bold blue pulsing **💬 New reply** chip and a blue highlighted row (home Active Orders, All orders list). Orders with an unread reply are moved to the top.
- Active Orders header shows "💬 N new replies" and the bottom **Orders** button shows a blue count badge.
- It clears when the storekeeper opens that order (note panel). No Firestore rule change needed.
- Once **Packing** has started, the storekeeper's note box (thread + type box + Send) is hidden inside the order. It appears only when the shop sends a new message, stays while he is in that order, and is hidden again next time.


## v1.0.206 Few left quantity (catalog item page)
- For **Few left** items only (stock 5 or less) the shop's catalog item page shows an orange pill **Only N left** with a 5-segment meter. In stock items still show no number; Out of stock unchanged.
- Size rows show a small "Only N left" badge. Lists / cards still show plain "Few left".
- The storekeeper phone publishes `fewQty` ("code=qty,...") to `shopCatalog/stockStatus` (Few left items only). **Open the app once on the storekeeper phone** after updating so it publishes; no Firestore rule change.


## v1.0.207 active-order banner only when it matters
- New order screen: the "Adding to your active order ... View" banner is now shown **only** when the shop has an existing order still **Pending / Checked** (packing not started) that the new items will be merged into. It shows that order's number (not the new draft number) and **View** opens that order's preview.
- If there is no such order (nothing open, or the last order is already Packing / Completed) the banner is hidden - no notification and no View.
- Updates live when the order status changes (e.g. packing starts -> banner disappears).


## v1.0.208 packing: notes Show / Hide
- Once Packing has started, the storekeeper sees a slim **💬 Notes with shop · N messages  Show ▾** bar (only if the order has notes). Tap to **Show / Hide** the full note box.
- It is collapsed by default, and **opens by itself when the shop sends a new message** (red NEW tag while collapsed). The order list "New reply" chip stays until the notes are opened.

## v1.0.209 auth redesign: splash + role selection + login
- New separate Role selection screen (Shop / Storekeeper / Admin cards) shown before login.
- Login screen: back arrow, role chip, no tabs; old tab buttons kept hidden so login logic is unchanged.
- Splash restyled (dark teal gradient, tagline).

## v1.0.210 simple catalogue: grid default + list toggle + quick add
- Catalogue opens straight on the item grid (category-tile landing removed); chips are plain pills (All / New / categories / Saved).
- Grid / List toggle next to search; choice is remembered (default Grid).
- Quick add: round + on each card/row adds 1 and turns into a - n + stepper (items with sizes/colours open the item page instead).
- Unit always comes from the stock list (catUnitFor), shown next to qty, not editable. No Pcs/Dzn/Box picker.
- Floating "N items in cart - View cart" bar; card hearts hidden (still on item page); "Swipe" pill hidden (swipe still works); calmer item page buttons.

## v1.0.227 admin can see all logins' passwords
- Admin -> **Shop Logins** and **Staff** list now show each account's password (masked, **Show** / **Copy**).
- Works for Shop, Storekeeper and Admin accounts. The password is saved when Admin creates the login, when the user changes it, and silently at every successful sign-in (so passwords changed or reset any other way also appear after that user's next login).
- Existing accounts show "Not known yet" until that user logs in once with the new version.
- Stored in Firestore `userSecrets/{uid}` (plain text, Admin-read only). **Firestore rules must be re-published** (`FIREBASE_FIRESTORE_RULES.txt`), otherwise nothing is saved/shown.

## v1.0.228 storekeeper: autosave, shop-change safety, faster ticks, steady lists
- **Autosave while packing:** every tick / qty / note change is saved on the phone at once and sent to the cloud ~2.5 s later; also saved the moment the app goes to the background. An app kill or dead phone no longer loses ticks (the local copy is restored when the order is opened again).
- **Shop edits can no longer be overwritten:** a view-only (Pending / Checked) order now follows the shop's changes live (qty, new items, removed items, cancel). Start Packing takes the shop's latest items from the cloud, and every save re-adds shop-added items / keeps shop removals.
- **Faster checklist:** a tick only re-draws the card that changed (other cards and photos are kept), and the scroll position is kept.
- **Live lists:** when orders change in the background the Orders / Shops lists keep their scroll position and the active search filter; the Shops list (done/total) now refreshes live too.

## v1.0.229 storekeeper UI polish
- Home order row: `#no · shop · items`, age (red when old), packing progress (12/20), status; URGENT tag if the order has an `urgent` flag.
- Search: inline box at the top (no popup), also matches item names.
- Shops list: `x/y done` plus red count of active (not finished) orders.
- Bell: real unread badge + notifications sheet (new orders, shop cancelled, items added/removed).
- Checklist: sticky progress bar, "Next unchecked" button, bigger tap areas, Out-of-stock UNDO toast, no "Start Packing" step (first tick starts packing automatically), Saved / Syncing / Offline chip.

## v1.0.230
- Start Packing button restored (auto-start removed); other v1.0.229 UI changes kept.

## v1.0.231 checklist bottom bar
- Complete button shows what is left ("Complete · 5 left") until every item is checked or out of stock.
- Complete is the wide main button, Save / WhatsApp stay small; Complete asks "Complete order?" before finishing.
