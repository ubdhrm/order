package com.orderslip.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import java.util.ArrayList;
import android.content.Context;
import android.webkit.MimeTypeMap;
import android.widget.Toast;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.ViewGroup;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;
import org.json.JSONArray;
import org.xmlpull.v1.XmlPullParser;
import android.util.Xml;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Collections;
import java.io.ByteArrayInputStream;
import java.io.BufferedInputStream;

public class MainActivity extends Activity {
    static volatile boolean inForeground = false;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER = 1001;
    private static final int CAMERA_CAPTURE = 1002;
    private static final int VOICE_INPUT = 1003;
    private static final int CAMERA_PERMISSION = 1003;
    private Uri cameraUri;
    private boolean updateCheckRunning = false;
    private boolean updateDialogShown = false;
    private File pendingInstallApk;
    private static final String UPDATE_PAGE = "https://github.com/ubdhrm/order/releases/latest";
    private static final String UPDATE_APK_URL = "https://github.com/ubdhrm/order/releases/latest/download/HBStoreHub.apk";
    private static final int STOCK_EXCEL_PICKER = 1010;
    private static final String STOCK_PREFS = "hb_stock_excel";
    private static final String STOCK_JSON_KEY = "stock_json";
    private static final String STOCK_FILE_KEY = "stock_file";
    private static final String STOCK_TIME_KEY = "stock_time";

    private final class StockExcelBridge {
        @android.webkit.JavascriptInterface
        public void pickExcel() {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    "application/vnd.ms-excel",
                    "application/octet-stream"
            });
            startActivityForResult(i, STOCK_EXCEL_PICKER);
        }

        private String defaultStockJson() {
            try {
                InputStream in = getAssets().open("stock/stock_default.json");
                java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
                byte[] b = new byte[16384]; int n;
                while ((n=in.read(b))!=-1) out.write(b,0,n);
                in.close();
                return out.toString("UTF-8");
            } catch (Exception e) { return "[]"; }
        }

        private String activeStockJson() {
            android.content.SharedPreferences p = getSharedPreferences(STOCK_PREFS, MODE_PRIVATE);
            String saved = p.getString(STOCK_JSON_KEY, "");
            return (saved == null || saved.trim().isEmpty()) ? defaultStockJson() : saved;
        }

        @android.webkit.JavascriptInterface
        public String getStockMeta() {
            try {
                android.content.SharedPreferences p = getSharedPreferences(STOCK_PREFS, MODE_PRIVATE);
                boolean hasSaved = p.contains(STOCK_JSON_KEY);
                JSONObject o = new JSONObject();
                o.put("fileName", hasSaved ? p.getString(STOCK_FILE_KEY, "") : "Book1.xlsx (default stock)");
                o.put("updatedAt", hasSaved ? p.getLong(STOCK_TIME_KEY, 0) : 0);
                o.put("count", new JSONArray(activeStockJson()).length());
                return o.toString();
            } catch (Exception e) { return "{\"fileName\":\"Book1.xlsx (default stock)\",\"updatedAt\":0,\"count\":0}"; }
        }

        @android.webkit.JavascriptInterface
        public String getStockData() {
            return activeStockJson();
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        // v1.0.50: background sync uses WorkManager, not a foreground service.
        // Stop any watcher left over from an older app version.
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        // Force every load of the bundled page to come straight from the APK's
        // assets, never from WebView's own disk cache. Without this, updating
        // the app (installing a new APK over the old one, which does NOT clear
        // app data/cache the way a full uninstall does) can silently keep
        // serving an old cached copy of index.html/CSS even though the new
        // file is sitting right there in the new APK.
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return false; }
            // LOCAL FIRST: the Firebase SDK scripts used to be downloaded again on every
            // launch (cache is disabled above), so the app waited on the network before
            // showing anything. They're now bundled straight into the APK's assets
            // (see serveFirebaseSdkFromDisk), so this never touches the network.
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                WebResourceResponse local = serveFirebaseSdkFromDisk(r);
                return local != null ? local : super.shouldInterceptRequest(v, r);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                // Android WebView does not always expose the HTML capture="environment"
                // flag consistently. Show our own image chooser so both Camera and Gallery
                // work reliably inside the APK.
                showImageChooser();
                return true;
            }
        });
        webView.addJavascriptInterface(new ShareBridge(this), "AndroidShare");
        webView.addJavascriptInterface(new StockExcelBridge(), "StockExcelBridge");
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#123B47"));
        root.addView(webView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        // Keep the page below the status bar even if the system draws edge-to-edge.
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(0, insets.getSystemWindowInsetTop(), 0, 0);
            return insets;
        });
        setContentView(root);
        webView.clearCache(true);
        webView.loadUrl("file:///android_asset/index.html");
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1004);
        }
        // Do not compete with the first screen render; check for updates shortly after startup.
        new Handler(Looper.getMainLooper()).postDelayed(() -> checkForUpdate(), 1500);
    }

    private WebResourceResponse serveFirebaseSdkFromDisk(WebResourceRequest r) {
        try {
            if (r == null || r.getUrl() == null) return null;
            if (!"GET".equalsIgnoreCase(r.getMethod())) return null;
            String host = r.getUrl().getHost();
            String path = r.getUrl().getPath();
            if (host == null || path == null) return null;
            if (!host.equals("www.gstatic.com") || !path.startsWith("/firebasejs/") || !path.endsWith(".js")) return null;

            // BUNDLED FIRST: the exact 3 SDK files this build was compiled against are
            // shipped inside app/src/main/assets/firebase/ (fetched once at build time
            // by the fetchFirebaseSdk Gradle task - see app/build.gradle). Reading an
            // asset never touches the network or the filesystem cache below, so this
            // is the normal path on every launch, reinstall, and storage clear.
            String assetName = path.substring(path.lastIndexOf('/') + 1);
            try {
                return new WebResourceResponse("application/javascript", "UTF-8",
                        getAssets().open("firebase/" + assetName));
            } catch (IOException notBundled) {
                // Falls through to the network-backed disk cache below. This only
                // happens if index.html's SDK version was bumped without re-running
                // a build that re-populates assets/firebase/ for the new version.
            }

            File dir = new File(getFilesDir(), "sdk_cache");
            if (!dir.exists() && !dir.mkdirs()) return null;
            File f = new File(dir, path.replace('/', '_'));
            if (!f.exists() || f.length() < 1000) {
                HttpURLConnection c = (HttpURLConnection) new URL(r.getUrl().toString()).openConnection();
                c.setConnectTimeout(8000);
                c.setReadTimeout(20000);
                if (c.getResponseCode() != 200) return null;
                File tmp = new File(dir, f.getName() + ".tmp");
                InputStream in = c.getInputStream();
                FileOutputStream out = new FileOutputStream(tmp);
                try {
                    byte[] buf = new byte[16384];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                } finally {
                    try { out.close(); } catch (Exception ignored) {}
                    try { in.close(); } catch (Exception ignored) {}
                }
                if (f.exists()) f.delete();
                if (!tmp.renameTo(f)) return null;
            }
            return new WebResourceResponse("application/javascript", "UTF-8", new FileInputStream(f));
        } catch (Exception e) {
            return null; // anything odd: let WebView fetch it from the network as before
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != STOCK_EXCEL_PICKER || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {}
        new Thread(() -> {
            try {
                final JSONArray rows = parseStockXlsx(uri);
                if (rows.length() == 0) throw new Exception("No Item Name / Item Code rows found in the Excel file.");
                String fileName = queryDisplayName(uri);
                if (fileName == null || fileName.trim().isEmpty()) fileName = "Stock Excel";
                getSharedPreferences(STOCK_PREFS, MODE_PRIVATE).edit()
                        .putString(STOCK_JSON_KEY, rows.toString())
                        .putString(STOCK_FILE_KEY, fileName)
                        .putLong(STOCK_TIME_KEY, System.currentTimeMillis())
                        .apply();
                final String js = "window.onStockExcelImported && window.onStockExcelImported(" +
                        JSONObject.quote(fileName) + "," + rows.length() + ");";
                runOnUiThread(() -> webView.evaluateJavascript(js, null));
            } catch (Exception e) {
                final String msg = e.getMessage() == null ? "Could not read Excel file" : e.getMessage();
                runOnUiThread(() -> webView.evaluateJavascript(
                        "window.onStockExcelImportFailed && window.onStockExcelImportFailed(" + JSONObject.quote(msg) + ");", null));
            }
        }).start();
    }

    private String queryDisplayName(Uri uri) {
        android.database.Cursor c = null;
        try {
            c = getContentResolver().query(uri, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {} finally { if (c != null) c.close(); }
        return null;
    }

    private JSONArray parseStockXlsx(Uri uri) throws Exception {
        File temp = File.createTempFile("stock_", ".xlsx", getCacheDir());
        try {
            InputStream in = getContentResolver().openInputStream(uri);
            if (in == null) throw new Exception("Cannot open Excel file.");
            FileOutputStream out = new FileOutputStream(temp);
            byte[] b = new byte[32768]; int n;
            while ((n = in.read(b)) != -1) out.write(b, 0, n);
            in.close(); out.close();

            ZipFile zip = new ZipFile(temp);
            List<String> shared = parseSharedStrings(zip);
            ZipEntry sheetEntry = null;
            for (java.util.Enumeration<? extends ZipEntry> en = zip.entries(); en.hasMoreElements();) {
                ZipEntry e = en.nextElement();
                String name = e.getName();
                if (name.startsWith("xl/worksheets/sheet") && name.endsWith(".xml")) { sheetEntry = e; break; }
            }
            if (sheetEntry == null) throw new Exception("Excel worksheet not found.");

            InputStream sin = zip.getInputStream(sheetEntry);
            XmlPullParser x = Xml.newPullParser();
            x.setInput(sin, "UTF-8");

            Map<Integer, String> headers = new HashMap<>();
            JSONArray result = new JSONArray();
            boolean inRow = false, inCell = false, inValue = false, inlineText = false;
            int rowNum = -1, col = -1, headerRow = -1;
            String cellRef = "", cellType = "", value = "", inline = "";
            Map<Integer,String> rowVals = new HashMap<>();

            int ev;
            while ((ev = x.next()) != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    String tag=x.getName();
                    if ("row".equals(tag)) {
                        inRow=true; rowVals.clear();
                        try { rowNum=Integer.parseInt(x.getAttributeValue(null,"r")); } catch(Exception ex){rowNum=-1;}
                    } else if (inRow && "c".equals(tag)) {
                        inCell=true; value=""; inline=""; cellRef=x.getAttributeValue(null,"r");
                        cellType=x.getAttributeValue(null,"t");
                        col=excelColumnIndex(cellRef);
                    } else if (inCell && "v".equals(tag)) {
                        inValue=true;
                    } else if (inCell && "t".equals(tag) && "inlineStr".equals(cellType)) {
                        inlineText=true;
                    } else if (inCell && "is".equals(tag)) {
                        // inlineStr wrapper; actual text is collected from <t>.
                    } else if (inCell && "t".equals(tag)) {
                        inlineText=true;
                    }
                } else if (ev == XmlPullParser.TEXT) {
                    if (inValue) value += x.getText();
                    else if (inlineText) inline += x.getText();
                } else if (ev == XmlPullParser.END_TAG) {
                    String tag=x.getName();
                    if ("v".equals(tag)) inValue=false;
                    else if ("t".equals(tag) && inlineText) inlineText=false;
                    else if ("c".equals(tag) && inCell) {
                        String raw = "inlineStr".equals(cellType) ? inline : value;
                        if ("s".equals(cellType)) {
                            try { int si=Integer.parseInt(raw.trim()); raw=(si>=0&&si<shared.size())?shared.get(si):""; } catch(Exception ignored){}
                        }
                        if (col>=0) rowVals.put(col, raw == null ? "" : raw.trim());
                        inCell=false;
                    } else if ("row".equals(tag) && inRow) {
                        if (headerRow<0) {
                            for (Map.Entry<Integer,String> en:rowVals.entrySet()) {
                                String h=en.getValue().toUpperCase().replaceAll("[^A-Z0-9]","");
                                if ("ITEMNAME".equals(h)) headers.put(en.getKey(),"name");
                                if ("ITEMCODE".equals(h)) headers.put(en.getKey(),"code");
                                if ("BARCODE".equals(h)) headers.put(en.getKey(),"barcode");
                                if ("UNIT".equals(h)) headers.put(en.getKey(),"unit");
                                if ("STOCK".equals(h) || "BALANCE".equals(h) || "STOCKQTY".equals(h) || "STOCKBALANCE".equals(h) || "AVAILABLE".equals(h) || "AVAILABLEQTY".equals(h) || "QTY".equals(h)) headers.put(en.getKey(),"balance");
                            }
                            if (headers.containsValue("name") && headers.containsValue("code")) headerRow=rowNum;
                        } else if (rowNum>headerRow) {
                            String name=rowVals.get(findHeader(headers,"name"));
                            String code=rowVals.get(findHeader(headers,"code"));
                            if (name!=null && !name.trim().isEmpty() && code!=null && !code.trim().isEmpty()) {
                                JSONObject o=new JSONObject();
                                o.put("n",name.trim());
                                o.put("c",code.trim());
                                String barcode=rowVals.get(findHeader(headers,"barcode"));
                                String unit=rowVals.get(findHeader(headers,"unit"));
                                String balance=rowVals.get(findHeader(headers,"balance"));
                                if(barcode!=null) o.put("b",barcode.trim());
                                if(unit!=null) o.put("u",unit.trim());
                                if(balance!=null && !balance.trim().isEmpty()) o.put("bal",balance.trim());
                                result.put(o);
                            }
                        }
                        inRow=false;
                    }
                }
            }
            sin.close(); zip.close();
            return result;
        } finally {
            try { temp.delete(); } catch(Exception ignored){}
        }
    }

    private int findHeader(Map<Integer,String> headers, String key) {
        for (Map.Entry<Integer,String> e:headers.entrySet()) if(key.equals(e.getValue())) return e.getKey();
        return -1;
    }

    private int excelColumnIndex(String ref) {
        if(ref==null) return -1;
        int n=0; for(int i=0;i<ref.length();i++){
            char ch=ref.charAt(i); if(ch<'A'||ch>'Z') break; n=n*26+(ch-'A'+1);
        }
        return n-1;
    }

    private List<String> parseSharedStrings(ZipFile zip) throws Exception {
        ZipEntry e=zip.getEntry("xl/sharedStrings.xml");
        if(e==null) return new ArrayList<>();
        List<String> out=new ArrayList<>();
        XmlPullParser x=Xml.newPullParser(); x.setInput(zip.getInputStream(e),"UTF-8");
        StringBuilder cur=null; int ev;
        while((ev=x.next())!=XmlPullParser.END_DOCUMENT){
            if(ev==XmlPullParser.START_TAG && "si".equals(x.getName())) cur=new StringBuilder();
            else if(ev==XmlPullParser.TEXT && cur!=null) cur.append(x.getText());
            else if(ev==XmlPullParser.END_TAG && "si".equals(x.getName()) && cur!=null){out.add(cur.toString());cur=null;}
        }
        return out;
    }

    @Override protected void onPause() {
        inForeground = false;
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        inForeground = true;
        if (pendingInstallApk != null && pendingInstallApk.exists()) {
            if (Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls()) {
                installApk(pendingInstallApk);
            }
        }
        if (!updateCheckRunning && !updateDialogShown) checkForUpdate();
    }

    private void checkForUpdate() { checkForUpdate(false); }

    /**
     * Check GitHub's latest release without relying on the GitHub API.
     * The API is rate-limited for unauthenticated devices and can return HTTP 403.
     * /releases/latest redirects to the current release page, so we use that redirect
     * (and the page HTML as a fallback) to discover the vNN release number.
     */
    void checkForUpdate(final boolean manual) {
        if (updateCheckRunning) {
            if (manual) Toast.makeText(this, "Already checking...", Toast.LENGTH_SHORT).show();
            return;
        }
        updateCheckRunning = true;
        if (manual) Toast.makeText(this, "Checking for update...", Toast.LENGTH_SHORT).show();

        new Thread(() -> {
            String problem = null;
            int remoteCode = 0;
            String releaseName = "New version";
            String apkUrl = null;
            try {
                // Do not use api.github.com here: normal phones frequently get HTTP 403
                // from the unauthenticated API rate limit. GitHub's public latest-release
                // page is not subject to that API limit.
                HttpURLConnection c = (HttpURLConnection) new URL(UPDATE_PAGE).openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(15000);
                c.setInstanceFollowRedirects(true);
                c.setRequestProperty("User-Agent", "HB-Store-Hub-Android/1.0");
                c.setRequestProperty("Accept", "text/html,application/xhtml+xml");
                int code = c.getResponseCode();
                if (code < 200 || code >= 400) throw new Exception("GitHub release page HTTP " + code);

                String finalUrl = c.getURL() == null ? "" : c.getURL().toString();
                InputStream in = c.getInputStream();
                java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                in.close();
                c.disconnect();
                String html = out.toString("UTF-8");

                // The final URL normally is .../releases/tag/v37. If a redirect is
                // hidden by a proxy, inspect the release page for the same canonical tag link.
                java.util.regex.Matcher tagMatcher = java.util.regex.Pattern
                        .compile("/releases/tag/v([0-9]+)")
                        .matcher(finalUrl + "\n" + html);
                if (tagMatcher.find()) {
                    remoteCode = Integer.parseInt(tagMatcher.group(1));
                }
                if (remoteCode <= 0) throw new Exception("Could not determine latest release version");

                releaseName = "HB Store Hub v1.0." + remoteCode;
                // Stable GitHub latest-release asset URL. GitHub redirects this to the
                // actual asset of the latest release.
                apkUrl = UPDATE_APK_URL;
            } catch (Exception e) {
                problem = e.getMessage();
            }

            final int rc = remoteCode;
            final String release = releaseName;
            final String url = apkUrl;
            final String prob = problem;
            runOnUiThread(() -> {
                int installedCode = installedVersionNumber();
                if (prob == null && rc > installedCode && url != null) {
                    showUpdateDialog(rc, release, url);
                } else if (manual) {
                    String msg;
                    if (prob != null) msg = prob;
                    else if (rc <= installedCode) msg = "You have the latest version (" + BuildConfig.VERSION_NAME + ").";
                    else msg = "A newer release was found, but its APK could not be located.";
                    new AlertDialog.Builder(this)
                            .setTitle(prob == null ? "No update needed" : "Update check failed")
                            .setMessage(msg)
                            .setPositiveButton("OK", null)
                            .show();
                }
            });
            updateCheckRunning = false;
        }).start();
    }

    /** BuildConfig.VERSION_CODE can be different from the release tag when building locally. */
    private int installedVersionNumber() {
        try {
            java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile("(?:^|\\.)([0-9]+)$")
                    .matcher(BuildConfig.VERSION_NAME == null ? "" : BuildConfig.VERSION_NAME);
            if (m.find()) return Integer.parseInt(m.group(1));
        } catch (Exception ignored) {}
        return BuildConfig.VERSION_CODE;
    }

    private void showUpdateDialog(int remoteCode, String releaseName, String apkUrl) {
        if (isFinishing() || updateDialogShown) return;
        updateDialogShown = true;
        new AlertDialog.Builder(this)
                .setTitle("New update available")
                .setMessage(releaseName + " is ready.\n\nCurrent version: " + BuildConfig.VERSION_NAME + "\nNew version: " + remoteCode + "\n\nUpdate now?")
                .setCancelable(false)
                .setNegativeButton("Later", (d, w) -> { updateDialogShown = false; })
                .setPositiveButton("Update", (d, w) -> downloadAndInstallUpdate(apkUrl))
                .show();
    }

    private void downloadAndInstallUpdate(String apkUrl) {
        Toast.makeText(this, "Downloading update...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            File dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "updates");
            if (!dir.exists()) dir.mkdirs();
            File apk = new File(dir, "HBStoreHub-update.apk");
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(apkUrl).openConnection();
                c.setConnectTimeout(10000); c.setReadTimeout(30000);
                c.setInstanceFollowRedirects(true);
                c.setRequestProperty("User-Agent", "HB-Store-Hub-Android");
                if (c.getResponseCode() != 200) throw new Exception("Download HTTP " + c.getResponseCode());
                InputStream in = c.getInputStream();
                FileOutputStream fos = new FileOutputStream(apk);
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) != -1) fos.write(buf, 0, n);
                fos.close(); in.close(); c.disconnect();
                runOnUiThread(() -> {
                    Toast.makeText(this, "Update downloaded", Toast.LENGTH_SHORT).show();
                    pendingInstallApk = apk;
                    installApk(apk);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    updateDialogShown = false;
                    new AlertDialog.Builder(this).setTitle("Update failed")
                            .setMessage("Could not download the new version. Please try again later.")
                            .setPositiveButton("OK", null).show();
                });
            }
        }).start();
    }

    private void installApk(File apk) {
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            new AlertDialog.Builder(this)
                    .setTitle("Allow app updates")
                    .setMessage("Android needs permission to install updates from this app. Enable it, then return here to continue the update.")
                    .setPositiveButton("Open Settings", (d, w) -> {
                        try {
                            Intent i = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()));
                            startActivity(i);
                        } catch (Exception e) { startActivity(new Intent(Settings.ACTION_SECURITY_SETTINGS)); }
                    })
                    .setNegativeButton("Later", null).show();
            return;
        }
        try {
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", apk);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Unable to open installer", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
    }


    /** Opens Google's speech dialog; the recognised text goes back to window.hbVoiceResult(text). */
    public void startVoice(String lang) {
        try {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, (lang == null || lang.isEmpty()) ? "ml-IN" : lang);
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say your items and quantities");
            startActivityForResult(i, VOICE_INPUT);
        } catch (Exception e) {
            sendVoiceToPage("");
        }
    }

    private void sendVoiceToPage(String text) {
        if (webView == null) return;
        final String js = "window.hbVoiceResult&&window.hbVoiceResult(" + JSONObject.quote(text == null ? "" : text) + ")";
        webView.post(new Runnable() { @Override public void run() { webView.evaluateJavascript(js, null); } });
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    results = new Uri[n];
                    for (int i = 0; i < n; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            if (fileCallback != null) { fileCallback.onReceiveValue(results); fileCallback = null; }
        } else if (requestCode == VOICE_INPUT) {
            String spoken = "";
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (r != null && !r.isEmpty()) spoken = r.get(0);
            }
            sendVoiceToPage(spoken);
        } else if (requestCode == CAMERA_CAPTURE) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && cameraUri != null) results = new Uri[]{cameraUri};
            if (fileCallback != null) { fileCallback.onReceiveValue(results); fileCallback = null; }
            cameraUri = null;
        }
    }

    private void showImageChooser() {
        final String[] choices = new String[]{"📷 Camera", "🖼 Gallery"};
        new AlertDialog.Builder(this)
                .setTitle("Add photo")
                .setItems(choices, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) startCamera(); else openPicker();
                    }
                })
                .setOnCancelListener(dialog -> cancelFileChooser())
                .show();
    }

    private void openPicker() {
        try {
            Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            pick.addCategory(Intent.CATEGORY_OPENABLE);
            pick.setType("image/*");
            pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
            startActivityForResult(pick, FILE_CHOOSER);
        } catch (Exception e) {
            // Some devices do not provide ACTION_OPEN_DOCUMENT; fall back to GET_CONTENT.
            try {
                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("image/*");
                startActivityForResult(pick, FILE_CHOOSER);
            } catch (Exception ignored) { cancelFileChooser(); }
        }
    }

    private void cancelFileChooser() {
        if (fileCallback != null) {
            fileCallback.onReceiveValue(null);
            fileCallback = null;
        }
    }

    private void startCamera() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION);
            return;
        }
        launchCamera();
    }

    private void launchCamera() {
        try {
            File dir = new File(getCacheDir(), "camera");
            if (!dir.exists()) dir.mkdirs();
            File photo = new File(dir, "photo_" + System.currentTimeMillis() + ".jpg");
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", photo);
            Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            cam.setClipData(ClipData.newRawUri("", cameraUri));
            cam.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            startActivityForResult(cam, CAMERA_CAPTURE);
        } catch (Exception e) {
            openPicker();   // no camera app -> let the user pick a photo instead
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) launchCamera();
            else openPicker();
        }
    }

    @Override public void onBackPressed() {
        // Let the page go one step back first (order -> shop orders -> shops); close the app only from the top screen.
        webView.evaluateJavascript(
                "(function(){try{return !!(window.hbHandleBack && window.hbHandleBack());}catch(e){return false;}})()",
                value -> {
                    if ("true".equals(value)) return;
                    if (webView.canGoBack()) webView.goBack(); else finish();
                });
    }
}
