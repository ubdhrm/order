package com.orderslip.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfDocument;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import java.util.concurrent.TimeUnit;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/** Native helpers the HTML calls as window.AndroidShare.* (WebView has no Web Share / file download). */
public class ShareBridge {
    private final Activity activity;
    private WebView pendingPdfWebView; // kept alive while the off-screen render + PDF write is in flight

    ShareBridge(Activity activity) { this.activity = activity; }

    private static String cleanName(String name, String fallback) {
        String n = name == null ? "" : name.replaceAll("[\\\\/:*?\"<>|\\r\\n]+", "").trim();
        return n.isEmpty() ? fallback : n;
    }

    private void toast(final String msg) {
        activity.runOnUiThread(() -> Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show());
    }

    private File writeToCache(String folder, String name, byte[] bytes) throws Exception {
        File dir = new File(activity.getCacheDir(), folder);
        if (!dir.exists()) dir.mkdirs();
        File[] old = dir.listFiles();
        if (old != null) for (File f : old) f.delete();   // keep cache small
        File out = new File(dir, name);
        FileOutputStream fos = new FileOutputStream(out);
        try { fos.write(bytes); } finally { fos.close(); }
        return out;
    }

    private void openShareSheet(final Uri uri, final String mime, final String text) {
        activity.runOnUiThread(() -> {
            try {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType(mime);
                send.putExtra(Intent.EXTRA_STREAM, uri);
                if (text != null && text.length() > 0) send.putExtra(Intent.EXTRA_TEXT, text);
                send.setClipData(ClipData.newRawUri("", uri));
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Intent chooser = Intent.createChooser(send, "Share order");
                chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                activity.startActivity(chooser);
            } catch (Exception e) {
                Toast.makeText(activity, "Could not open share", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /** Send the order file through the Android share sheet (WhatsApp etc). */
    @JavascriptInterface
    public void shareHtml(String filename, String html, String text) {
        try {
            String name = cleanName(filename, "Order.html");
            File f = writeToCache("shared", name, html.getBytes("UTF-8"));
            Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", f);
            openShareSheet(uri, "text/html", text);
        } catch (Exception e) {
            toast("Could not share order");
        }
    }

    /** Share plain text straight to WhatsApp (falls back to the share sheet). */
    @JavascriptInterface
    public void shareText(final String text) {
        activity.runOnUiThread(() -> {
            String[] pkgs = {"com.whatsapp", "com.whatsapp.w4b"};
            for (String pkg : pkgs) {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                    send.setPackage(pkg);
                    activity.startActivity(send);
                    return;
                } catch (Exception ignored) { }
            }
            try {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                activity.startActivity(Intent.createChooser(send, "Share order"));
            } catch (Exception e) {
                Toast.makeText(activity, "Could not open share", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /** Render an HTML order summary to a real PDF (off-screen WebView snapshotted onto a
     *  PdfDocument page -- no print dialog, and no private Android print-framework classes)
     *  and hand it straight to WhatsApp, falling back to the general share sheet. */
    @JavascriptInterface
    public void sharePdf(final String filename, final String html, final String text) {
        startRender(filename, html, text, false);
    }

    /** Same render as sharePdf, but shared as a PNG image (opens WhatsApp directly). */
    @JavascriptInterface
    public void sharePng(final String filename, final String html, final String text) {
        startRender(filename, html, text, true);
    }

    private void startRender(final String filename, final String html, final String text, final boolean asPng) {
        activity.runOnUiThread(() -> {
            try {
                final int widthPx = 1000; // fixed render width; content height is measured after load
                final WebView pdfWeb = new WebView(activity);
                pendingPdfWebView = pdfWeb; // hold a strong ref so it isn't GC'd mid-render

                // Rendered off-screen but still attached to the window, since some devices only
                // lay out WebView content correctly for capture once it's part of the hierarchy.
                ViewGroup root = (ViewGroup) activity.getWindow().getDecorView();
                ViewGroup.LayoutParams lp = new ViewGroup.LayoutParams(widthPx, 10);
                pdfWeb.setLayoutParams(lp);
                pdfWeb.setTranslationX(-20000f);
                root.addView(pdfWeb);

                pdfWeb.setWebViewClient(new WebViewClient() {
                    @Override
                    public void onPageFinished(WebView view, String url) {
                        // Small delay so inline images/layout settle before we measure & snapshot.
                        view.postDelayed(() -> renderWebViewToPdf(view, widthPx, filename, text, asPng), 150);
                    }
                });
                pdfWeb.loadDataWithBaseURL(null, html == null ? "" : html, "text/html", "UTF-8", null);
            } catch (Exception e) {
                toast(asPng ? "Could not create image" : "Could not create PDF");
            }
        });
    }

    private void renderWebViewToPdf(final WebView view, final int widthPx, final String filename, final String text, final boolean asPng) {
        Bitmap full = null;
        PdfDocument doc = null;
        try {
            float scale = view.getScale();
            if (scale <= 0f) scale = 1f;
            int contentHeightPx = (int) Math.ceil(view.getContentHeight() * scale);
            if (contentHeightPx <= 0) contentHeightPx = widthPx;
            if (contentHeightPx > 20000) contentHeightPx = 20000; // sanity cap

            // Re-layout at the real content height (not just the tiny placeholder height)
            // so drawing the view captures the whole order, not only the first sliver.
            view.measure(
                    View.MeasureSpec.makeMeasureSpec(widthPx, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(contentHeightPx, View.MeasureSpec.EXACTLY));
            view.layout(0, 0, widthPx, contentHeightPx);

            full = Bitmap.createBitmap(widthPx, contentHeightPx, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(full);
            canvas.drawColor(Color.WHITE);
            view.draw(canvas);

            String name = cleanName(filename, asPng ? "Order.png" : "Order.pdf");
            File dir = new File(activity.getCacheDir(), "shared");
            if (!dir.exists()) dir.mkdirs();
            File[] old = dir.listFiles();
            if (old != null) for (File f : old) f.delete();
            File out = new File(dir, name);

            if (asPng) {
                FileOutputStream pos = new FileOutputStream(out);
                try { full.compress(Bitmap.CompressFormat.PNG, 100, pos); } finally { pos.close(); }
            } else {
                doc = new PdfDocument();
                PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(widthPx, contentHeightPx, 1).create();
                PdfDocument.Page page = doc.startPage(info);
                page.getCanvas().drawBitmap(full, 0f, 0f, null);
                doc.finishPage(page);

                FileOutputStream fos = new FileOutputStream(out);
                try { doc.writeTo(fos); } finally { fos.close(); }
            }

            cleanupPdfWebView(view);
            Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", out);
            shareFileToWhatsapp(uri, asPng ? "image/png" : "application/pdf", text);
        } catch (Exception e) {
            cleanupPdfWebView(view);
            toast(asPng ? "Could not create image" : "Could not create PDF");
        } finally {
            if (doc != null) doc.close();
            if (full != null) full.recycle();
        }
    }

    private void cleanupPdfWebView(final WebView view) {
        activity.runOnUiThread(() -> {
            try {
                ViewGroup parent = (ViewGroup) view.getParent();
                if (parent != null) parent.removeView(view);
                view.destroy();
            } catch (Exception ignored) {}
            if (pendingPdfWebView == view) pendingPdfWebView = null;
        });
    }

    /** Send a file (e.g. the generated PDF) straight to WhatsApp, falling back to the share sheet. */
    private void shareFileToWhatsapp(final Uri uri, final String mime, final String text) {
        activity.runOnUiThread(() -> {
            String[] pkgs = {"com.whatsapp", "com.whatsapp.w4b"};
            for (String pkg : pkgs) {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType(mime);
                    send.putExtra(Intent.EXTRA_STREAM, uri);
                    if (text != null && text.length() > 0) send.putExtra(Intent.EXTRA_TEXT, text);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    send.setPackage(pkg);
                    activity.startActivity(send);
                    return;
                } catch (Exception ignored) { }
            }
            openShareSheet(uri, mime, text);
        });
    }

    /** Save a photo (data URL) to Pictures/OrderSlip. */
    @JavascriptInterface
    public void savePhoto(String filename, String dataUrl) {
        try {
            String name = cleanName(filename, "photo.jpg");
            byte[] bytes = Base64.decode(dataUrl.substring(dataUrl.indexOf(',') + 1), Base64.DEFAULT);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/OrderSlip");
                Uri uri = activity.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new Exception("insert failed");
                OutputStream os = activity.getContentResolver().openOutputStream(uri);
                try { os.write(bytes); } finally { os.close(); }
            } else {
                File f = writeToCache("shared", name, bytes);
                Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", f);
                openShareSheet(uri, "image/jpeg", null);
            }
        } catch (Exception e) {
            toast("Could not save photo");
        }
    }

    /** Show a system notification right now (kept for the HTML; the background service uses OrderNotifier directly). */
    @JavascriptInterface
    public void showNotification(String title, String body) {
        OrderNotifier.show(activity, title, body);
    }

    /** "Check for update" button in the Saved tab. */
    @JavascriptInterface
    public void checkUpdate() {
        if (activity instanceof MainActivity) {
            final MainActivity a = (MainActivity) activity;
            activity.runOnUiThread(() -> a.checkForUpdate(true));
        }
    }

    /** Installed app version (shown in the Saved tab so it is easy to see which build is running). */
    @JavascriptInterface
    public String getVersion() { return BuildConfig.VERSION_NAME; }

    /** Starts background sync without a persistent/running notification.
     * WorkManager performs an immediate one-time sync and then periodic sync while the app is closed.
     * Android may delay periodic work; the in-app Firestore listener remains real-time while open.
     */
    @JavascriptInterface
    public void startWatcher(String role, String uid, String refreshToken) {
        try {
            if (role == null || uid == null || refreshToken == null || refreshToken.isEmpty()) return;
            SharedPreferences sp = activity.getSharedPreferences(OrderSyncWorker.PREFS, Context.MODE_PRIVATE);
            boolean sameUser = uid.equals(sp.getString("uid", "")) && role.equals(sp.getString("role", ""));
            SharedPreferences.Editor ed = sp.edit()
                    .putString("role", role).putString("uid", uid).putString("refreshToken", refreshToken);
            if (!sameUser) ed.remove("shopMap").remove("skLast").remove("skSeen");
            ed.apply();

            Constraints constraints = new Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build();
            WorkManager wm = WorkManager.getInstance(activity.getApplicationContext());

            OneTimeWorkRequest now = new OneTimeWorkRequest.Builder(OrderSyncWorker.class)
                    .setConstraints(constraints).build();
            wm.enqueueUniqueWork("hb_order_sync_now", ExistingWorkPolicy.REPLACE, now);

            PeriodicWorkRequest periodic = new PeriodicWorkRequest.Builder(OrderSyncWorker.class, 15, TimeUnit.MINUTES)
                    .setConstraints(constraints).build();
            wm.enqueueUniquePeriodicWork("hb_order_sync", ExistingPeriodicWorkPolicy.UPDATE, periodic);
        } catch (Exception ignored) {}
    }

    /** Stops background sync on logout. */
    @JavascriptInterface
    public void stopWatcher() {
        try {
            activity.getSharedPreferences(OrderSyncWorker.PREFS, Context.MODE_PRIVATE).edit()
                    .remove("role").remove("uid").remove("refreshToken")
                    .remove("shopMap").remove("skLast").remove("skSeen").apply();
            WorkManager wm = WorkManager.getInstance(activity.getApplicationContext());
            wm.cancelUniqueWork("hb_order_sync_now");
            wm.cancelUniqueWork("hb_order_sync");
        } catch (Exception ignored) {}
    }
}
